from django.urls import path
from . import views

urlpatterns = [
    path('search', views.SearchApi.as_view(), name='search'),
    path('sponsor-shop', views.SponsorShoppingApi.as_view(), name='sponsor-shop'),
    path('driver-shop', views.DriverShoppingApi.as_view(), name='driver-shop'),
    path('related-shop', views.RelatedInventoryApi.as_view(), name='related-shop'),
    path('buy', views.BuyApi.as_view(), name='buy'),
]
