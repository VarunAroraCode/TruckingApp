from django.db import models

# Create your models here.
class Item(models.Model):
    productName = models.CharField(max_length=150)
    image = models.CharField(max_length=200)
    productCost = models.FloatField()
    productReviews = models.IntegerField()

    def __str__(self):
        return self.productName

class Cart(models.Model):
    items = models.ManyToManyField(Item)
    driver = models.ForeignKey(
             'accounts.Driver',
             on_delete=models.CASCADE,
             related_name='carts'
             )
    sponsor = models.ForeignKey(
              'accounts.Sponsor',
              on_delete=models.CASCADE,
              related_name='driver_carts',
              )

    class Meta:
        unique_together = (('sponsor', 'driver'))


class Inventory(models.Model):
    items = models.ManyToManyField(Item)
    sponsor = models.OneToOneField(
              'accounts.Sponsor',
              on_delete=models.CASCADE,
              unique=True,
              )

class Purchase(models.Model):
    item = models.ForeignKey(
             Item,
             on_delete=models.CASCADE,
             related_name='purchases')
    driver = models.ForeignKey(
             'accounts.Driver',
             on_delete=models.CASCADE,
             related_name='purchases'
             )
    sponsor = models.ForeignKey(
              'accounts.Sponsor',
              on_delete=models.CASCADE,
              related_name='purchases',
              )
    fee = models.FloatField()
    address = models.CharField(max_length=300)
    created_at = models.DateTimeField(auto_now_add=True)
