from django.apps import AppConfig


class EbayConfig(AppConfig):
    name = 'web.ebay'
