from django.shortcuts import render
from ebaysdk.exception import ConnectionError
from ebaysdk.finding import Connection
import rest_framework.status
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import get_user_model
from django.apps import apps
from web.trucker_api.serializers import ItemSerializer
from web.loggingTest.logs import *

# sets up custom user instead of default django user
User = get_user_model()

def parse_params(url):
    # params now string of param list
    to_return = {}
    params = url.split('?')[1]
    params = params.split('&')
    for param in params:
        try:
            (name, value) = param.split('=')
            to_return[name] = value
        except:
            to_return[param] = ""
    return to_return

#
class SearchApi(APIView):

    def get(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params


        api = Connection(domain='svcs.sandbox.ebay.com', appid='BrettLud-TruckerA-SBX-edc78fcfb-ea9d18b1', config_file=None)
        try:
            response = api.execute('findItemsAdvanced', {'keywords': data['search'] , 'outputSelector': ['GalleryInfo','SellerInfo']} )
            items = []
            # used for only showing unique items
            names = []
            if len(response.reply.searchResult.item) > 20:
                times = 20
            else:
                times = len(response.reply.searchResult.item)
            for i in range(times):
                raw_item = response.reply.searchResult.item[i]
                if raw_item.title in names:
                    continue
                else:
                    names.append(raw_item.title)
                item = {}
                item['productName'] = raw_item.title
                item['productCost'] = raw_item.sellingStatus.currentPrice.value
                item['productReviews'] = raw_item.sellerInfo.positiveFeedbackPercent
                try:
                    item['image'] = raw_item.galleryURL
                except:
                    item['image'] = ''
                items.append(item)

            return Response({'items':items})
#            return Response(response.dict())
        except:
            return Response({'error': api.error()})

# Api for sponsors to edit their inventory
# Get:
# returns list of items
# Post:
# supports adding and removing items to inventory
class SponsorShoppingApi(APIView):

    def get(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if user.user_type == 'D':
            return Response({'error' : 'Must be sponsor to use this api'})
        elif user.user_type == 'A':
            try:
                sponsor = User.objects.filter(username=data['view_as'])[0].sponsor
            except:
                return Response({'error': 'failed to view as this user'})
        else:
            sponsor = user.sponsor

        try:
            return Response({'items' : [ItemSerializer(i).data for i in sponsor.inventory.items.all()] })
        except:
            return Response({'items':[]})


    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data
        user = self.request.user

        if user.user_type != 'S':
            return Response({'error' : 'Must be sponsor to use this api'})

        Item = apps.get_model('ebay', 'Item')

        if 'add' in data:
            for item in data['add']:
                try:
                    # if item already stored in database just get it else, make a new entry
                    try:
                        i = Item.objects.filter(name=item['productName'])[0]
                    except:
                        i = Item(productName= item['productName'],
                                 productCost = float(item['productCost']),
                                 image = item['image'],
                                 productReviews = int(float(item['productReviews'])) )
                        i.save()

                    user.sponsor.inventory.items.add(i)

                except:
                    return Response({'error': 'failed to add items'})

        if 'remove' in data:
            for item in data['remove']:
                try:
                    i = user.sponsor.inventory.items.filter(productName=item['productName'])[0]
                    user.sponsor.inventory.items.remove(i)
                except:
                    return Response({'error': 'failed to remove items'})

        user.save()
        return Response({'success':'changed items'})


class DriverShoppingApi(APIView):

    def get(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if user.user_type == 'S':
            return Response({'error' : 'Must be driver to use this api'})
        elif user.user_type == 'A':
            try:
                driver = User.objects.filter(username=data['view_as'])[0].driver
            except:
                return Response({'error': 'failed to view as this user'})
        else:
            driver = user.driver

        try:
            items = []
            for cart in driver.carts.all():
                sponsor_username = cart.sponsor.account.username
                for item in cart.items.all():
                    itm = ItemSerializer(item).data
                    itm['sponsor'] = sponsor_username
                    items.append(itm)

            return Response({'items' : items })
        except:
            return Response({'items':[]})


    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data
        user = self.request.user

        if user.user_type != 'D':
            return Response({'error' : 'Must be driver to use this api'})

        Item = apps.get_model('ebay', 'Item')
        sponsor_username = data['sponsor_username']
        try:
            cart = user.driver.carts.filter(sponsor__account__username=sponsor_username)[0]
        except:
            return Response({'error':'this sponsor is not related to you'})

        if 'add' in data:
            for item in data['add']:
                try:
                    # if item already stored in database just get it else, make a new entry
                    try:
                        i = Item.objects.filter(name=item['productName'])[0]
                    except:
                        i = Item(productName= item['productName'],
                                 productCost = float(item['productCost']),
                                 image = item['image'],
                                 productReviews = int(float(item['productReviews'])) )
                        i.save()
                    #Log test
                    cart.items.add(i)
                    logCartAddition(i, 1, "TestID")
                except:
                    return Response({'error': 'failed to add items'})
        if 'remove' in data:
            for item in data['remove']:
                try:
                    sponsor = User.objects.filter(username=data['sponsor_username'])[0].sponsor
                    i = user.driver.carts.filter(sponsor=sponsor)[0].items.filter(productName=item['productName'])[0]
                    #Log test
                    cart.items.remove(i)
                    #Log item removal from cart
                    logCartRemoval(i, 1, "TestID")
                except:
                    return Response({'error': 'failed to remove items'})

        user.save()
        return Response({'success':'changed items'})



# GET:
# drivers:
#   get items from their sponsors inventories
# sponsors:
#   get items from their drivers carts
class RelatedInventoryApi(APIView):

    def driver_get(self, user):
        items = []
        try:
            sponsors = user.driver.sponsors.all()
        except:
            sponsors = []

        # loop over all sponors
        for sponsor in sponsors:
            sponsor_name = sponsor.account.username
            sponsor_items = sponsor.inventory.items.all()
            # loops over all items of the sponsor

            for itm in sponsor_items:
                item = ItemSerializer(itm).data
                item['sponsor'] = sponsor_name
                items.append(item)
        return Response({'items' : items})

    def sponsor_get(self, user):
        items = []
        try:
            drivers = user.sponsor.drivers.all()
        except:
            drivers = []

        # loop over all drivers
        for driver in drivers:
            driver_name = driver.account.username
            driver_items = driver.carts.filter(sponsor__account__username=user.username)[0].items.all()
            # loops over all items of the driver

            for itm in driver_items:
                item = ItemSerializer(itm).data
                item['driver'] = driver_name
                items.append(item)
        return Response({'items' : items})



    def get(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if 'view_as' in data and data['view_as'] != '':
            try:
                view_as = User.objects.filter(username=data['view_as'])[0]
            except:
                return Response({'error': 'failed to view as this user'})
            if view_as.user_type == 'D':
                return self.driver_get(view_as)
            elif user.user_type == 'A':
                return self.sponsor_get(view_as)
        elif user.user_type == 'D':
            return self.driver_get(user)
        elif user.user_type == 'S':
            return self.sponsor_get(user)

        return Response({'error':'failed to get related items'})

class BuyApi(APIView):

    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data
        user = self.request.user

        # get the models I'll need
        Sponsor = apps.get_model('accounts', 'Sponsor')
        Purchase = apps.get_model('ebay', 'Purchase')


        # get the data from the request
        try:
            if not 'address' in data or data['address'] == '':
                address = '123 clemson way'
            else:
                address = data['address']
            sponsor_username = data['sponsor_username']
        except:
            return Response({'error': "you need an address to ship the items to and the sponsor who's cart you're buying"})

        if user.user_type != 'D':
            return Response({'error':'user must be a driver to purchase their cart'})

        # find the items user is trying to buy and the sponsor who they are
        # buying from
        try:
            cart = user.driver.carts.filter(sponsor__account__username = sponsor_username)[0]
        except:
            return Response({'error':'driver is not related to this sponsor'})

        # get the sponsor
        sponsor = Sponsor.objects.filter(account__username = sponsor_username)[0]
        # get their points to cents
        conversion = sponsor.points_to_cents


        # calculate the cost and fee
        total_cost = 0
        total_fee = 0
        purchases = []
        for item in cart.items.all():
            cost = item.productCost
            fee = cost * .01
            p = Purchase(item=item,driver=user.driver,sponsor=sponsor,fee=fee, address=address)
            purchases.append(p)

            total_fee += fee
            total_cost += cost

        # can they afford this? if not tell them
        points = total_cost / conversion
        user_point_obj = user.driver.points_set.filter(sponsor__account__username = sponsor_username)[0]
        if points > user_point_obj.points:
            return Response({'error' : "you cannot afford your cart"})

        # buy the items and store the purchases + fee
        user_point_obj.points -= points
        user_point_obj.save()
        cart.items.clear()
        logPointChange(user.username, "Purchase",  user.first_name, user.last_name, str(user_point_obj.points), points, sponsor_username)
        for p in purchases:
            p.save()

        return Response({'success':'bought items in your cart, it cost %d points' % points})
