from django.apps import AppConfig


class TruckerSiteConfig(AppConfig):
    name = 'web.trucker_site'
