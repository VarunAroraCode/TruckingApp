from django.db import models
from django.conf import settings
from django.contrib.auth import get_user_model
from django.apps import apps
UserTypes = ['D', 'A', 'S']


def default_account(user_type):
    if(user_type not in UserTypes):
        return None

    User = get_user_model()
    username = user_type
    try:
        acct = User.objects.filter(username=username)[0]
    except:
        acct = User.objects.create_user(username=username, email=username, password="", user_type=user_type)
        acct.first_name = "john"
        acct.last_name = "doe"
        acct.save()

    return acct.pk

class Driver(models.Model):
    account = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        primary_key = True,
        default=default_account('D'),
        )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    

    def __str__(self):
        return self.account.username

class Sponsor(models.Model):
    account = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        primary_key = True,
        default=default_account('S'),
        )
    drivers = models.ManyToManyField(Driver, related_name='sponsors')
    points_to_cents = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.account.username

class Request(models.Model):
    sponsor = models.ForeignKey(
        Sponsor,
        on_delete=models.CASCADE)
    driver  = models.ForeignKey(
        Driver,
        on_delete=models.CASCADE)
    # this is used to know the result of a request and for logging
    # None means request not answered yet
    # true means approved
    # false means denied
    status  = models.BooleanField(default=None, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        unique_together = (('sponsor', 'driver'))

class Points(models.Model):
    points = models.IntegerField(default=0)
    sponsor = models.ForeignKey(
        Sponsor,
        on_delete=models.CASCADE)
    driver  = models.ForeignKey(
        Driver,
        on_delete=models.CASCADE)

    class Meta:
        unique_together = (('sponsor', 'driver'))

class PointChange(models.Model):
    point_change = models.IntegerField()
    reason = models.CharField(max_length=200)
    driver  = models.ForeignKey(
        Driver,
        on_delete=models.CASCADE)
    sponsor = models.ForeignKey(
        Sponsor,
        on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
