from django.contrib.auth import get_user_model
from django.apps import apps
from rest_framework.test import APITestCase
from web.trucker_api.serializers import UserSerializer, RequestSerializer, SponsorSerializer, DriverSerializer
import json


User = get_user_model()
base_url = "http://ec2-52-205-135-163.compute-1.amazonaws.com/"

# ----- API Requests ------

def get_csrf():
    client = RequestsClient()

    response = client.get('http://127.0.0.1/set-csrf')
    print(response.status_code)
    assert response.status_code == 200

    return response.cookies['csrftoken']

# ----- Test Functions ----

class RegistrationTestCase(APITestCase):

    def test_registration(self):
        res = self.client.post("/set-csrf")
        print(res.status_code)

def register_acct(usr_name, pswd, rpswd, u_type, fname, lname, email):
    factory = APIRequestFactory(enforce_csrf_checks=True)
    body = {
        'username': usr_name,
        'password': pswd,
        'repassword': rpswd,
        'user_type': u_type,
        'first_name': fname,
        'last_name': lname,
        'email': email,
    }
    response = factory.post('/register', body)
    print(json.loads(response.content))


def create_test_sponsors():
    pass
