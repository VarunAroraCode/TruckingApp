infile = r"logs.log"

important = []

with open(infile) as f:
    f = f.readlines()

for line in f:
    stringyboi = line;
    if(stringyboi[0] == ":"):
        showLine = (stringyboi, "\n")
        important.append(showLine)

i = 0
with open("filteredLogs.txt", "w") as f2:
    for logs in important:
        print(important[i], file = f2)
        i += 1
