from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager


UserTypes = ['D', 'A', 'S']

class UserManager(BaseUserManager):

    def create_user(self, username, password, user_type, email):
        if(user_type not in UserTypes):
            return None
        user = self.model(username=username, user_type=user_type, email=email)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, password, user_type, email):
        user = self.create_user(username, password, user_type, email)
        user.is_admin = True;
        user.save(using=self._db)

        return user

class User(AbstractBaseUser, PermissionsMixin):

    # fields
    username = models.CharField(max_length=150, unique=True)
    email = models.CharField(max_length=150, unique=True)
    user_type = models.CharField(max_length=1)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    # matches django default auth better with this
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['user_type', 'email']

    objects = UserManager()

    def __str__(self):
        return self.username

    @property
    def is_staff(self):
        return self.is_admin
