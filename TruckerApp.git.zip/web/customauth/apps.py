from django.apps import AppConfig


class CustomauthConfig(AppConfig):
    name = 'web.customauth'
