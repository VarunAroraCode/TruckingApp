This application is responsible for logging information as defined by our User Stories. 

To date, the logging functionality lies within this directory, 
and is bound to function calls defined within loggerTest.py.

Any logs calls thrown within that file during execu34tion will send their log data to test.log.

Test.log can be read with any non-graphical editor.
