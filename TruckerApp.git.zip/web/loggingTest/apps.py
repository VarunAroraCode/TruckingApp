from django.apps import AppConfig


class LoggingtestConfig(AppConfig):
    name = 'web.loggingTest'
