import logging
import time
from datetime import  date


#def logPointChange(pointsToSummate, driverID):
#   logger = logging.getLogger('django')
#   
#    if(pointsToSummate > 0):
#        logger.info(":{}: Added {} points to Driver: {}".format(time.asctime(), pointsToSummate, driverID))
#        #print("{}: Added {} points to Driver: {}".format(time.asctime(), pointsToSummate, driverID))
#    if(pointsToSummate < 0):
#        logger.info(":{}: Subtracted {} points from Driver: {}".format(time.asctime(), abs(pointsToSummate), driverID))

def getLogs():
    path = 'logs.txt'
    logs = []
    with open(path, 'r') as f:
        lines = f.readlines()
        for line in lines:
           logs.append(line) 
    f.close()
    return logs

def putLogs(logs):
    path = 'logs2.txt'
    with open(path, 'w') as f:
        f.write(message)
    f.close()

def categorizeLogs(logs):
    path    = 'logs2.txt'
    logDict = {"LoginAttempt":[]}
    split   = []
    #with open(path, 'w') as f:
    for log in logs:
        split = log.split(":", 2)
        del split[0]
        logDict[str(split[0])].append(str(split[1]))
    return logDict

def logRecord(message):
    path = 'logs.txt'
    with open(path, 'a') as f:
        f.write(str(message + "\n"))
    f.close()

#def logCartAddition(itemID, qty, driverID):
#    logger = logging.getLogger('django')
#    logRecord(str(":"": Added {} instances of item: {} to Driver:{}'s cart".format(time.asctime(), qty, itemID, driverID)))
#    logger.info(":{}: Added {} instances of item: {} to Driver:{}'s cart".format(time.asctime(), qty, itemID, driverID))

#def logCartRemoval(itemID, qty, driverID):
#    logger = logging.getLogger('django') 
#    logRecord(str(":{}: Removed {} intances of item: {} from Driver:{}'s cart".format(time.asctime(), qty, itemID, driverID)))
#    logger.info(":{}: Removed {} intances of item: {} from Driver:{}'s cart".format(time.asctime(), qty, itemID, driverID))


#def logPurchase(itemID, qty, driverID):
#    logger = logging.getLogger('django')
#    logger.info(":{}: Driver: {} purchased: {} instances of item: {}.".format(time.asctime(), qty, itemID, driverID))
#    logger.info(":{}: Driver: {} purchased: {} instances of item: {}.".format(time.asctime(), qty, itemID, driverID))
#    logCartRemoval(itemID, qty, driverID)


def logApplicationResponse(sponsorName, userName, status, reason):
    logger = logging.getLogger('django')
    today = date.today()
    logRecord(str(":DriverApplication:" + sponsorName +":"+ userName +":"+ status +":"+ reason +":"+ today.strftime("%d/%m/%Y")))
    logger.info(":DriverApplication:{}:{}:{}:{}:{}".format(sponsorName, userName, status, reason, today.strftime("%d/%m/%Y")))

def logLoginSuccess(userName):
    logger = logging.getLogger('django')
    today = date.today()
    logRecord(str(":LoginAttempt:"+ userName +":Success"+ ":" + today.strftime("%d/%m/%Y")))
    logger.info(":LoginAttempt:{}:Success:{}".format(userName, today.strftime("%d/%m/%Y")))

def logLoginFailure(userName):
    logger = logging.getLogger('django')
    today = date.today()
    logRecord(str(":{}:{}:Failure:{}".format("LogginAttempt", userName, today.strftime("%d/%m/%Y"))))
    logger.info(":{}:{}:Failure:{}".format("LoginAttempt", userName, today.strftime("%d/%m/%Y")))

def logPasswordUpdate(userID, role, password):
    logger = logging.getLogger('django')
    today = date.today()
    
    if(role == 'A'):
        roleString = "Admin"
    if(role == 'D'):
        roleString = "Driver"
    if(role == 'S'):
        roleString = "Sponsor"
    logRecord(str(":{}:{}:{}:{}:{}".format("PasswordChange", roleString, userID, password, today.strftime("%d/%m/%Y"))))

    logger.info(":{}:{}:{}:{}:{}".format("PasswordChange", roleString, userID, password, today.strftime("%d/%m/%Y")))

def logPointChange(userName, reason, firstName, lastName, totalPoints, pointChange, sponsorName):
    logger = logging.getLogger('django')
    today = date.today()
    logRecord(str(":{}:{}:{}:{}:{}:{}:{}:{}:{}".format("PointChange", userName, firstName, lastName, totalPoints, pointChange, reason, sponsorName, today.strftime("%d/%m/%Y"))))
    logger.info(":{}:{}:{}:{}:{}:{}:{}:{}:{}".format("PointChange", userName, firstName, lastName, totalPoints, pointChange, reason, sponsorName, today.strftime("%d/%m/%Y")))



#logPointChange(10, "A")
#logCartAddition(1, 2, "B")
#logCartRemoval(1, 1, "C")

#logLogginSuccess("User1", 'D')
#logLogginFailure("badUsername", "badPassword")



