from django.shortcuts import render
import rest_framework.status
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.views import APIView
from web.loggingTest.logs import  logPointChange


def parse_params(url):
    # params now string of param list
    to_return = {}
    params = url.split('?')[1]
    params = params.split('&')
    for param in params:
        try:
            (name, value) = param.split('=')
            to_return[name] = value
        except:
            to_return[param] = ""
    return to_return

class test(APIView):

    def get(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
    
        points = int(data['points'])
        driver_id = data['driver_id']
        try:
            logPointChange(points, driver_id)
            return Response({'success': 'proff I have run'})
        except:
            return Response({'error': 'uh oh'})
