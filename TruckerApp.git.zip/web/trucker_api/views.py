import json
from datetime import datetime
# drf
import rest_framework.status
from rest_framework import permissions
from rest_framework.response import Response
from rest_framework.views import APIView
# django
from django.middleware.csrf import  get_token
from django.views.decorators.csrf import ensure_csrf_cookie, csrf_protect
from django.utils.decorators import method_decorator
from django.contrib.auth import get_user_model
from django.contrib import auth
from django.apps import apps
from web.trucker_api.serializers import UserSerializer, RequestSerializer, SponsorSerializer, DriverSerializer, PointsSerializer, PointChangeSerializer, PurchaseSerializer
from web.loggingTest.logs import *



# sets up custom user instead of default django user
User = get_user_model()

def parse_params(url):
    # params now string of param list
    to_return = {}
    params = url.split('?')[1]
    params = params.split('&')
    for param in params:
        try:
            (name, value) = param.split('=')
            to_return[name] = value
        except:
            to_return[param] = ""
    return to_return


@method_decorator(ensure_csrf_cookie, name='dispatch')
class GetCSRFToken(APIView):
    permission_classes = (permissions.AllowAny, )

    def get(self, request, format=None):
        return Response({'success': 'CSRF cookie set'})

@method_decorator(csrf_protect, name='dispatch')
class GetUsersView(APIView):

    def get(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        # start will all users and then apply filters
        # return final result
        # allows for optional query params
        query_result = User.objects.all()
        if 'user_type' in data:
            requested_type = data['user_type']
            if requested_type == 'A' and user.user_type != 'A':
                return Response({'error':'Your user type cannot request to see admins'})
            query_result = query_result.filter(user_type=requested_type)

        users = [ UserSerializer(x).data for x in query_result]
        return Response({'users':users})

    def put(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data

        username = data['username']
        point_change = data['point_change']
        reason = data['reason']



@method_decorator(csrf_protect, name='dispatch')
class RegisterView(APIView):
    permission_classes = (permissions.AllowAny, )

    def create_related_objects(self, user, user_type):
        # Make additional models if necessary
        if user_type == 'D':
            Driver = apps.get_model('accounts', 'Driver')
            driver = Driver(account=user)
            driver.save()
        elif user_type == 'S':
            Sponsor = apps.get_model('accounts', 'Sponsor')
            sponsor = Sponsor(account=user)
            sponsor.points_to_cents = 1
            sponsor.save()

            Inventory = apps.get_model('ebay', 'Inventory')
            inventory = Inventory(sponsor=sponsor)
            inventory.save()



    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data


        # Variable extraction
        username = data['username']
        password = data['password']
        fname = data['first_name']
        lname = data['last_name']
        email = data['email']
        re_password = data['re_password']
        user_type = data['user_type']

        # User Type Check
        if( user_type not in ['D', 'A', 'S'] ):
            return Response({ 'error' : 'Improper user type'})

        # Create User in Sql
        try:
            if password == re_password:
                if User.objects.filter(username=username).exists():
                    return Response({ 'error': 'user already exist' })
                else:
                    user = User.objects.create_user(username=username, email=email, password=password, user_type=user_type)
                    user.first_name = fname
                    user.last_name = lname
                    user.save()
            else:
                return Response({ 'error': 'Passwords do not match' })
        except:
            return Response({ 'error': 'Something went wrong' })

        if user != None:
            self.create_related_objects(user, user_type)
            return Response({'success':'User created successfully'})
        else:
            return Response({'error':'Something went wrong'})

#method_decorator(csrf_protect, name='dispatch')
@method_decorator(csrf_protect, name='dispatch')
class LoginView(APIView):
    permission_classes = (permissions.AllowAny, )

    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = request.data



        username = data['username']
        password = data['password']

        try:
            user = auth.authenticate(username=username, password=password)

            if user is not None:
                auth.login(request, user)

                logLoginSuccess(username)

                return Response({
                        'success' : 'User Authenticated',
                        'user_type' : user.user_type,
                    })
            else:

                try:
                    logLoginFailure(username)
                except:
                    pass
                return Response({ 'error': 'Your username or password is incorrect'})

        except:
            return Response({'error':'Something went wrong logging in'})

@method_decorator(csrf_protect, name='dispatch')
class LogoutView(APIView):
    def post(self, request, format=None):
            try:
                auth.logout(request)
                return Response({'success': 'Logged Out'})
            except:
                return Response({'error' : 'Something went wrong logging out'})

@method_decorator(csrf_protect, name='dispatch')
class RequestSponsorView(APIView):

    # either accepts or denies a user's request to a sponsor
    # if accepting:
    #   creates sponsor related items
    # elif deleting (setting status true to false):
    #   deletes sponsor related items
    # else:
    #   updates status but nothing else
    def update_request(self, user, driver_username, new_status):
        # Get models needed for this api
        Cart = apps.get_model('ebay', 'Cart')
        Request = apps.get_model('accounts', 'Request')
        Points = apps.get_model('accounts', 'Points')

        driver_user = User.objects.filter(username=driver_username)[0]

        # ensure user is of type sponsor before making request
        if(driver_user == None or driver_user.user_type != 'D'):
            return Response({'error':'user does not exist or is not a driver'})

        # try to find the request request
        driver = driver_user.driver
        sponsor = user.sponsor
        request = Request.objects.filter(driver=driver, sponsor=sponsor)
        if len(request) == 0:
            return Response({'error':'request not found'})

        # change value of request
        request = request[0]
        old_status = request.status
        request.status = new_status
        request.save()

        if(new_status == True): # create drivers sponsor related items
            # create new items
            try:
                logApplicationResponse(sponsor.username, driver.username, "Accepted", "Driver has been sponsored")
            except:
                pass
            cart = Cart(driver=request.driver, sponsor=request.sponsor)
            points = Points(driver=request.driver, sponsor=request.sponsor)
            # update sponsor
            sponsor.drivers.add(driver)
            # save changes
            cart.save()
            points.save()
            sponsor.save()
        elif old_status == True and new_status == False: # delete drivers sponsor related items
            try:
                logApplicationResponse(sponsor.username, driver.username, "Terminated/Rejected", "Driver has been Terminated or Rejected by sponsor")
            except:
                pass
            cart = Cart.objects.filter(driver=request.driver, sponsor=request.sponsor)
            points = Points.objects.filter(driver=request.driver, sponsor=request.sponsor)

            cart.delete()
            points.delete()

        return Response({'success':'status was updated'})

    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = request.data
        user = self.request.user


        if(user == None):
            return Response({'error': 'issue getting user'})

        if( user.user_type == 'D'):
            # extract data and get the sponsor you want to request
            try:
                sponsor_username = data['sponsor_username']
                sponsor_user = User.objects.filter(username=sponsor_username)[0]
            except:
                return Response({'error':'could not find sponsor'})

            # ensure user is of type sponsor before making request
            if(sponsor_user == None or not hasattr( sponsor_user, 'sponsor') ):
                return Response({'error':'user does not exist or is not a sponsor'})

            # create request
            driver = user.driver
            sponsor = sponsor_user.sponsor
            Request = apps.get_model('accounts', 'Request')
            request = Request(sponsor=sponsor, driver=driver)
            request.save()
            return Response({'sucess': 'Request has been made'})
        else:
            driver_username = data['driver_username']
            new_status = data['new_status'] == 'true'
            return self.update_request(user, driver_username, new_status)



    def get(self,request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if(user == None):
            return({'error': 'issue getting user'})

        if( user.user_type == 'S'):
            sponsor = user.sponsor
        elif( user.user_type == 'A'):
            # get body
            try:
                if 'view_as' in data and data['view_as'] != '':
                    sponsor_username = data['view_as']
                else:
                    sponsor_username = data['sponsor_username']
                sponsor = User.objects.filter(username=sponsor_username)[0].sponsor
            except:
                Response({'error':'body not formatted properly'})
        else:
            return Response({'error':'User cannot use this api'})

        Request = apps.get_model('accounts', 'Request')
        requests = [ RequestSerializer(x).data for x in Request.objects.filter(sponsor=sponsor)]
        return Response({'requests':requests})

@method_decorator(csrf_protect, name='dispatch')
class MyInfoView(APIView):

    def get(self, request, format=None):
        user = self.request.user
        return Response({'user' : UserSerializer(user).data })

    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data
        user = self.request.user
        details = []

        if 'user_to_change' in data and data['user_to_change'] != '':
            try:
                to_change = User.objects.filter(username=data['user_to_change'])[0]
            except:
                return Response({'error':'cannot find this user'})
        else:
            to_change = user

        if('username' in data and data['username'] != ""):
            users = User.objects.filter(username=data['username'])
            if( len(users) == 0 ):
                to_change.username = data['username']
            else:
                details.append('new username must be unique')

        if('email' in data and data['email'] != "" ):
            users = User.objects.filter(email=data['email'])
            if( len(users) == 0 ):
                to_change.email = data['email']
            else:
                details.append('new email must be unique')


        if('password' in data and 're_password' in data and data['password'] != ""):
            if(data['password'] == data['re_password']):
                to_change.set_password(data['password'])
                logPasswordUpdate(user.username, user.user_type, str(data['password']))
            else:
                details.append('passwords must match!')

        if('first_name' in data and data['first_name'] != ''):
            to_change.first_name = data['first_name']

        if('last_name' in data and data['last_name'] != ''):
            to_change.last_name = data['last_name']

        to_change.save()
        return Response({'success':'profile updated', 'details': details})

@method_decorator(csrf_protect, name='dispatch')
class DriverView(APIView):

    # post to change how many points a driver has
    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data
        user = self.request.user

        if user.user_type != 'S':
            return Response({'error': 'Must be sponsor to change points'})

        PointChange = apps.get_model('accounts', 'PointChange')
        try:
            driver_username = data['driver_username']
            point_change = data['point_change']
            reason = data['reason']
        except:
            return Response({'error': 'request body formatted wrong'})

        try:
            driver = User.objects.filter(username=driver_username)[0].driver
            if driver not in user.sponsor.drivers.all():
                return Response({'error': 'cannot change points of an unrelated driver'})
        except:
            return Response({'error': 'failed to find requested driver'})

        # create change object
        change = PointChange(driver=driver, sponsor=user.sponsor, point_change=point_change, reason=reason)
        change.save()
        # change drivers points
        point_obj = driver.points_set.filter(sponsor=user.sponsor)[0]
        try:
            logPointChange(driver_username, reason, driver.first_name, driver.last_name, str(point_obj.points), str(point_change), reason, user.username)
        except:
            pass

        point_obj.points += int(point_change)
        point_obj.save()
        return Response({'success': 'driver now has %d points' % point_obj.points})

    def get_points_driver(self, driver):
        points = []
        for p in driver.points_set.all():
            point = PointsSerializer(p).data
            point['sponsor'] = p.sponsor.account.username
            points.append(point)
        # return Driver related attributes
        return points

    def get_points_sponsor(self, sponsor):
        points = []
        for p in sponsor.points_set.all():
            point = PointsSerializer(p).data
            point['driver'] = p.driver.account.username
            points.append(point)
        return points

    # get how many points a driver has
    def get(self, request, format= None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if 'view_as' in data and data['view_as'] != "":
            try:
                view_as = User.objects.filter(username=data['view_as'])[0]
                if view_as.user_type == 'D' and user.user_type != 'D':
                    points = self.get_points_driver(view_as.driver)
                elif user.user_type == 'A':
                    points = self.get_points_sponsor(view_as.sponsor)
            except:
                return Response({'error': 'canot find this user'})
        elif( user.user_type == 'D'):
            driver = user.driver
            points = self.get_points_driver(driver)
        elif(user.user_type == 'S'):
            sponsor = user.sponsor
            points = self.get_points_sponsor(sponsor)
        elif 'sponsor_username' in data and user.user_type == 'A':
            Sponsor = apps.get_model('accounts','Sponsor')
            try:
                sponsor_username = data['sponsor_username']
                sponsor = Sponsor.objects.filter(account__username=sponsor_username)[0]
            except:
                return Response({'error': 'admin needs to provide an existing sponsor username'})
            points = self.get_points_sponsor(sponsor)
        else:
            points = []

        return Response({'points':points})



@method_decorator(csrf_protect, name='dispatch')
class SponsorView(APIView):

    #permission_classes = (permissions.IsAuthenticated, )
    def get(self, request, format= None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if(user == None):
            return({'error': 'issue getting user'})

        # get sponsor obj
        if 'view_as' in data and data['view_as'] != "":
            try:
                view_as = User.objects.filter(username=data['view_as'])[0]
                if view_as.user_type == 'D' and user.user_type != 'D':
                    user = view_as
                elif user.user_type == 'A':
                    user = view_as
            except:
                return Response({'error': 'canot find this user'})

        if user.user_type == 'S':
            sponsor = user.sponsor
        elif user.user_type == 'D':
            try:
                sponsor_username = data['sponsor_username']
                sponsor = user.driver.sponsors.filter(account__username=sponsor_username)[0]
            except:
                return Response({'error':'failed to process request, check params'})
        else:
            if 'driver_username' in data: # if admin wants all sponsors related to a driver
                try:
                    driver_username = data['driver_username']
                    driver = User.objects.filter(username=driver_username)[0].driver
                except:
                    return Response({'error':'failed to process request, check params'})
                sponsors = [SponsorSerializer(s).data for s in driver.sponsors.all()]
                return Response({'sponsors': sponsors})
            else: # if sponsor just wants one sponsor
                try:
                    sponsor_username = data['sponsor_username']
                    sponsor = User.objects.filter(username=sponsor_username)[0].sponsor
                except:
                    return Response({'error':'failed to process request, check params'})



        points_to_cents = sponsor.points_to_cents
        return Response({'points_to_cents': points_to_cents})



    def post(self, request, format=None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.data
        user = self.request.user

        if(user == None):
            return({'error': 'issue getting user'})

        if( hasattr( user, 'sponsor') ):
            sponsor = user.sponsor
            sponsor.points_to_cents = int(data['points_to_cents'])
            sponsor.save()
            return Response({'success': 'points changed'})

        return Response({'error': 'something went wrong updating sponsor'})


@method_decorator(csrf_protect, name='dispatch')
class SponsorReportView(APIView):

    #permission_classes = (permissions.IsAuthenticated, )
    def get(self, request, format= None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        PointChange = apps.get_model('accounts', 'PointChange')
        if user.user_type == 'D':
            return Response({'error':'drivers cannot view this report'})

        if "driver_username" in data:
            try:
                driver_username = data['driver_username']
                driver = User.objects.filter(username=driver_username)[0].driver
                changes = PointChange.objects.filter(driver=driver, sponsor=user.sponsor)
            except:
                return Response({'error':'failed to get specified driver'})
        else:
            changes = user.sponsor.pointchange_set.all()

        if "date_start" in data and data['date_start'] != '':
            data['date_start'] = data['date_start'].replace('%2F', '/')
            try:
                # the gte is greater than or equal, just denotes operation of comparison
                changes = changes.filter(created_at__gte = datetime.strptime(data['date_start'], '%m/%d/%Y'))
            except:
                return Response({'error':'date_start not formatted correctly'})
        if "date_end" in data and data['date_end'] != '':
            data['date_end'] = data['date_end'].replace('%2F', '/')
            try:
                date = datetime.strptime(data['date_end'], '%m/%d/%Y')
                # set time of given date to latest possible to get all point changes that occured this day
                date = date.replace(hour=23, minute=59, second=59)
                changes = changes.filter(created_at__lte = date)
            except:
                return Response({'error':'date_end not formatted correctly'})


        changes = [PointChangeSerializer(pc).data for pc in changes]
        return Response({'changes':changes})

@method_decorator(csrf_protect, name='dispatch')
class PurchaseReportView(APIView):

    def driver_get(self, driver):
        return driver.purchases.all()

    def sponsor_get(self, sponsor, driver_username = None):
        if driver_username != None:
            driver = sponsor.drivers.filter(driver__account__username=driver_username)[0]
            return driver.purchases.all()
        else:
            return sponsor.purchases.all()

    def admin_get(self, user, data):
        Purchase = apps.get_model('ebay', 'Purchase')
        if 'driver_username' in data and data['driver_username'] != '':
            driver = User.objects.filter(username=data['driver_username'])[0].driver
            return self.driver_get(driver)
        elif 'sponsor_username' in data and data['sponsor_username'] != '':
            sponsor = User.objects.filter(username=data['sponsor_username'])[0].sponsor
            return self.sponsor_get(sponsor)
        else:
            return Purchase.objects.all()

    def get(self, request, format= None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        try:
            if user.user_type == 'D':
                purchases = self.driver_get(user.driver)
            elif user.user_type == 'S':
                if 'driver_username' in data and data['driver_username'] != '':
                    purchases = self.sponsor_get(user.sponsor, data['driver_username'])
                else:
                    purchases = self.sponsor_get(user.sponsor)
            elif user.user_type == 'A':
                purchases = self.admin_get(user, data)
        except:
            return Response({'purchases':[]})

        if "date_start" in data and data['date_start'] != '':
            data['date_start'] = data['date_start'].replace('%2F', '/')
            try:
                # the gte is greater than or equal, just denotes operation of comparison
                purchases = purchases.filter(created_at__gte = datetime.strptime(data['date_start'], '%m/%d/%Y'))
            except:
                return Response({'error':'date_start not formatted correctly'})
        if "date_end" in data and data['date_end'] != '':
            data['date_end'] = data['date_end'].replace('%2F', '/')
            try:
                date = datetime.strptime(data['date_end'], '%m/%d/%Y')
                # set time of given date to latest possible to get all point changes that occured this day
                date = date.replace(hour=23, minute=59, second=59)
                purchases = purchases.filter(created_at__lte = date)
            except:
                return Response({'error':'date_end not formatted correctly'})

        purchases = [PurchaseSerializer(p).data for p in purchases]
        return Response({'purchases':purchases})

@method_decorator(csrf_protect, name='dispatch')
class InvoiceReportView(APIView):

    def get_invoice(self, sponsor, date_start, date_end):
        purchases = sponsor.purchases.all()
        if date_start != None:
            purchases = purchases.filter(created_at__gte = date_start)
        if date_end != None:
            purchases = purchases.filter(created_at__lte = date_end)
        purchases = [PurchaseSerializer(p).data for p in purchases]

        fee_dict = {}
        for p in purchases:
            driver_username = p['driver']['username']
            if driver_username in fee_dict:
                fee_dict[driver_username] += p['fee']
            else:
                fee_dict[driver_username] = p['fee']

        breakdown = []
        total_fee = 0
        for (name, driver_fee) in fee_dict.items():
            breakdown.append({'driver':name, 'total_fee':driver_fee})
            total_fee += driver_fee

        invoice = {
            'sponsor':sponsor.account.username,
            'total_fee': total_fee,
            'breakdown': breakdown
        }
        return invoice

    def get(self, request, format= None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if user.user_type != 'A':
            return Response({'error':'must be an admin to see this report'})

        # get variables form data
        if "date_start" in data and data['date_start'] != '':
            data['date_start'] = data['date_start'].replace('%2F', '/')
            date_start = datetime.strptime(data['date_start'], '%m/%d/%Y')
        else:
            date_start = None

        if "date_end" in data and data['date_end'] != '':
            data['date_end'] = data['date_end'].replace('%2F', '/')
            date_end = datetime.strptime(data['date_end'], '%m/%d/%Y')
            # set time of given date to latest possible to get all point changes that occured this day
            date_end = date.replace(hour=23, minute=59, second=59)
        else:
            date_end = None


        # process invoice
        if 'sponsor_username' in data and data['sponsor_username'] != '':
            try:
                sponsor = User.objects.filter(username=data['sponsor_username'])[0].sponsor
                invoices = [self.get_invoice(sponsor, date_start, date_end)]
            except:
                return Response({'error':'could not get invoice for that sponsor'})
        else:
            Sponsor = apps.get_model('accounts','Sponsor')
            invoices = []
            for s in Sponsor.objects.all():
                invoices.append(self.get_invoice(s, date_start, date_end))


        return Response({'invoices':invoices})

@method_decorator(csrf_protect, name='dispatch')
class LogReportView(APIView):

    #def get_logsByDate(self, log_category, date_start, date_end):
        #if date_start != None:
        #    data['date_start'] = data['date_start'].replace('%2', '/')
        #    logs = logs.filter(created_at__gte = date_start)
        #if date_end != None:
        #    data['date_end'] = data['date_end'].replace('%2', '/')
        #    logs = logs.filter(created_at__lte = date_end)
        #logs = [LogSerializer(l).data for l in purchases]
     #   file.open('logs.txt', 'r')
      #  print(file.read())
       # file.close()

    def get_logsByDate(self, request, format= None):
        try:
            data = parse_params(request.get_full_path())
        except:
            data = self.request.query_params
        user = self.request.user

        if user.user_type != 'A':
            return Response({'error':'must be an admin to see this report'})

        #if("log_category" in data and data['log_category'] != ''):
            log_category = log_category

        else:
            log_category = None


        if "date_start" in data and data['date_start'] != '':
            date_start = datetime.strptime(data['date_start'], '%m/%d/%Y')
        else:
            date_start = None

        if "date_end" in data and data['date_end'] != '':
            date_end = datetime.strptime(data['date_end'], '%m/%d/%Y')
        else:
            date_end = None

        #Process Log
        try:
            logs = [self.get_logsByDate(date_start, date_end)]
            return Response({'logs':logs})
        except:
            return Response({'error': 'could not get log entries'})
