from django.urls import path
from . import views

urlpatterns = [
    # auth urls
    path('login/', views.LoginView.as_view(), name='login'), 
    path('logout/', views.LogoutView.as_view(), name='logout'), 
    path('register/', views.RegisterView.as_view(), name='register'), 
    path('set-csrf/', views.GetCSRFToken.as_view(), name='set-csrf'), 
    # urls for getting user info
    path('my-info/', views.MyInfoView.as_view(), name='my-info'), 
    path('driver-info/', views.DriverView.as_view(), name='driver-info'), 
    path('sponsor-info/', views.SponsorView.as_view(), name='sponsor-info'), 
    path('sponsor-request/', views.RequestSponsorView.as_view(), name='sponsor-request'), 
    path('get-users/', views.GetUsersView.as_view(), name=' get-users'), 
    path('sponsor-report/', views.SponsorReportView.as_view(), name='sponsor-report'), 
    path('purchase-report/', views.PurchaseReportView.as_view(), name='purchase-report'), 
    path('invoice-report/', views.InvoiceReportView.as_view(), name='invoice-report'), 
    path('log-report/', views.LogReportView.as_view(), name='log-report'), 
    
]     
