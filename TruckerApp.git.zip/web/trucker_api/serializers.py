from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.apps import apps

User = get_user_model()


# ------------- EBAY SERIALIZER ------------------------

class ItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = apps.get_model('ebay', 'Item')
        fields = ['productName', 'image', 'productCost', 'productReviews']

# ------------- ACCOUNT SERIALIZERS -------------------------------
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'user_type', 'first_name', 'last_name']

class DriverSerializer(serializers.ModelSerializer):
    account = UserSerializer(read_only=True)
    class Meta:
        model = apps.get_model('accounts', 'Driver')
        fields = ['account']

class SponsorSerializer(serializers.ModelSerializer):
    account = UserSerializer(read_only=True)
    class Meta:
        model = apps.get_model('accounts', 'Sponsor')
        fields = ['account', 'points_to_cents']

class RequestSerializer(serializers.ModelSerializer):
    driver = DriverSerializer(read_only=True )
    class Meta:
        model = apps.get_model('accounts', 'Request')
        fields = ['driver', 'status']

class PointsSerializer(serializers.ModelSerializer):
    class Meta:
        model = apps.get_model('accounts', 'Points')
        fields = ['points']

class PointChangeSerializer(serializers.ModelSerializer):
    driver = UserSerializer(read_only=True , source = 'driver.account')
    sponsor = UserSerializer(read_only=True, source = 'sponsor.account')
    class Meta:
        model = apps.get_model('accounts', 'PointChange')
        fields = ['point_change', 'reason', 'driver', 'sponsor', 'created_at']

class PurchaseSerializer(serializers.ModelSerializer):
    item = ItemSerializer(read_only=True)
    driver = UserSerializer(read_only=True , source = 'driver.account')
    sponsor = UserSerializer(read_only=True, source = 'sponsor.account')
    status = serializers.ReadOnlyField(default='in delivery')
    class Meta:
        model = apps.get_model('ebay', 'Purchase')
        fields = ['item', 'driver', 'sponsor', 'fee','address', 'status']
