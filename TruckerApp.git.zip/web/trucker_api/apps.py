from django.apps import AppConfig


class TruckerApiConfig(AppConfig):
    name = 'web.trucker_api'
