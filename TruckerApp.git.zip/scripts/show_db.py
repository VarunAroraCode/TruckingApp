from django.contrib.auth import get_user_model
from django.apps import apps
from web.trucker_api.serializers import UserSerializer, RequestSerializer, SponsorSerializer, DriverSerializer


User = get_user_model()

def print_all_users():
    users = User.objects.all()
    for user in users:
        print(UserSerializer(user).data)


def run():
    print_all_users()
