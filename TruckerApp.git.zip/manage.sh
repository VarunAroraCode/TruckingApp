#!/bin/bash

python3.7 manage.py makemigrations
python3.7 manage.py migrate
