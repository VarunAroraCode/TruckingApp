import React, { Component } from 'react';
import axios from 'axios';
import {Container, Navbar, Nav,  Form, Button} from 'react-bootstrap';
// authentication
import { login, set_csrf } from './backend/auth.jsx';
import CSRFToken from './backend/CSRFToken.jsx';
import { Link, withRouter } from 'react-router-dom'
import './Login.css';

class Login extends Component {

    constructor(props){
	super(props);
	this.state={
	    username:'',
	    password:'',
	    auth: {
		valid: false,
		userType: ""
	    }
	}
	this.handleClick = this.handleClick.bind(this);
	this.handleUsernameChange = this.handleUsernameChange.bind(this);
	this.handlePasswordChange = this.handlePasswordChange.bind(this);
    }
	
	componentDidMount(){
		  set_csrf().then( res => {console.log(res);});
	  }

    componentDidMount() {
	set_csrf().then( res => {console.log(res);});
    }

    handleClick(event){
	login(this.state.username, this.state.password)
	    .then(res => {
		    var data = res['data'];
		    console.log(data);
		    if("success" in data){

			let userData = {
			    userType: data.user_type,
			    username: this.state.username,
			};
			// Passing up global data
			this.props.passupAuth(true);
			this.props.passupUserData(userData);

			switch(data.user_type){
			    case "D" : 
				// This is a functional way to push pages as opposed to Link elements
				// You need to export withRouter (see bottom of file) to have this
				this.props.history.push("/DriverHome");
				break;
			    case "A":
				this.props.history.push("/AdminHome");
				break;
			    case "S":
				this.props.history.push("/SponsorHome");
				break;
			}
		    }else{
			    alert("login failed");
		    }
	    });
	    event.preventDefault();
	    return false;	  
    }

    handleUsernameChange(e) {
	    this.setState({username:e.target.value});
    }
    handlePasswordChange(e) {
	    this.setState({password:e.target.value});
    }
	handleRegister(event){
		this.props.history.push("/Register");
	}

     
    render() {
	return (
	<Container fluid>
	    <Navbar collapseOnSelect expand="lg" bg="light"  >
		<Navbar.Collapse>	
		<Navbar.Brand>
		    <Nav.Link as={Link} to='/'>Trucking Rewards</Nav.Link>
		</Navbar.Brand>
		</Navbar.Collapse>
	    </Navbar>
	    <Form>
		<CSRFToken />
		<Form.Group controlId="formUsername">
		    <Form.Label>Username</Form.Label>
		    <Form.Control type="text" placeholder="Username" onChange = {this.handleUsernameChange} />
		</Form.Group>
		<br/>
		<Form.Group controlId="formPassword">
		    <Form.Label>Password</Form.Label>
		    <Form.Control type="password" placeholder="Password" onChange = {this.handlePasswordChange} />
		</Form.Group>
		<br/>
		<Button label="Submit" type="submit" onClick={(event) => this.handleClick(event)}>
			Login
		</Button>
		<Button label="Register" onClick={(event) => this.handleRegister(event)}>
			Register
		</Button>
	    </Form>
	</Container>
	);
    }
}

export default withRouter(Login);
