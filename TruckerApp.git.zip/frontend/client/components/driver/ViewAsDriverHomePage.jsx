import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import {get_users, send_request} from '../backend/accounts.jsx';
import {driver_info} from '../backend/driver.jsx';


class ViewAsDriverHomePage extends Component{
    
  constructor(props) {
      super(props);
      this.state = {
	 sponsorList: [{sponsor:'', points: ''}]
      }
      this.handleClick = this.handleClick.bind(this);
      this.renderTableData = this.renderTableData.bind(this)
    }
    handleClick() {
      console.log("hi");
      logout();
      this.props.history.push("/");
    }

       componentDidMount(){
	driver_info("",this.props.passDownUsername).then( res => {
	var data = [];
	res.data.points.forEach ( item => data.push(
		{
			sponsor: item.sponsor,
			points: item.points
		}));
        this.setState({sponsorList: data});
        });
      }  
        
   renderTableData() {
   return this.state.sponsorList.map((data, index) => {
   const { points, sponsor } = data //destructuring
   return (
   <tr key={sponsor}>
   <td>
   Sponsor Name: {sponsor} <br/> 
   Available Points: {points} <br/>
   -------------------------- <br/> <br/>
       </td>
      </tr>
    )
   })
  }
	                                                                                                                        
	    

  render() {
      return(
        <div>

          <h1>Welcome Driver CHANGE HERE JUST CHECKING {this.props.passDownUsername}!</h1> <br/><br/><br/>

          <h3>Your Current Sponsors: </h3><br/><br/>
          <table>
                 <tbody>
                    {this.renderTableData()}
                 </tbody>
              </table>
        </div>
      )
  }
}
export default withRouter(ViewAsDriverHomePage);
