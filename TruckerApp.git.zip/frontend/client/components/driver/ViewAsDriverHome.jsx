import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import {logout} from '../backend/auth.jsx';
import {driver_info} from '../backend/driver.jsx';
import {send_request} from '../backend/accounts.jsx';
import {withRouter} from 'react-router-dom';
import ViewAsDriverCart from './ViewAsDriverCart.jsx' ;
import ViewAsDriverCatalog from './ViewAsDriverCatalog.jsx';
import ViewAsDriverSettings from './ViewAsDriverSettings.jsx';
import ViewAsDriverHomePage from './ViewAsDriverHomePage.jsx';
import ViewAsDriverApplication from './ViewAsDriverApplication.jsx';
import ViewAsDriverHomeNav from './ViewAsDriverHomeNav.jsx';
import ViewAsPurchaseHistory from './ViewAsPurchaseHistory.jsx';
import SponsorHome from '../sponsor/SponsorHome.jsx';


import  './driverHome.css';
//adding a comment to narrow down nginx bug
class ViewAsDriverHome extends Component{
    constructor(props) {
      super(props);
      this.state = {
        username: this.props.location.state.passDownUsername,
        points : 0,
      }
      this.handleClick = this.handleClick.bind(this);
      }
      handleClick() {
        logout();
        this.props.history.push("/");
      }

      componentDidMount() {
        console.log(this.props.location.state.passDownUsername)
        console.log(this.state.username)
        driver_info().then( res => {
          console.log(res);
            this.setState({points:res.data['points']});
        });
      }

      render() {
        return(
        <div>
            <ViewAsDriverHomeNav></ViewAsDriverHomeNav>
        <Switch>
            <Route exact path={this.props.match.path}> <ViewAsDriverHomePage passDownUsername={this.state.username}/></Route>
            <Route path={this.props.match.path+"/ViewAsDriverCatalog"}> <ViewAsDriverCatalog passDownUsername={this.state.username}/></Route>
            <Route path={this.props.match.path+"/ViewAsDriverCart"} > <ViewAsDriverCart passDownUsername={this.state.username}/>  </Route>
            <Route path={this.props.match.path+"/ViewAsDriverSettings"} > <ViewAsDriverSettings passDownUsername={this.state.username}/>  </Route>
            <Route path={this.props.match.path+"/ViewAsDriverApplication"} > <ViewAsDriverApplication passDownUsername={this.state.username}/>  </Route>
            <Route path={this.props.match.path+"/ViewAsPurchaseHistory"} > <ViewAsPurchaseHistory passDownUsername={this.state.username}/>  </Route>
            <Route path={this.props.match.path+"/SponsorHome"} > <SponsorHome />  </Route>
            
        </Switch>
        </div>
        ) 
      }
}
export default withRouter(ViewAsDriverHome);
