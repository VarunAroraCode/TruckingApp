import React, { Component } from 'react';
//import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './driverHome.css'
import {driver_shop, related_shop} from '../backend/ebay.jsx';
import {driver_purchase_history} from '../backend/driver.jsx';



class PurchaseHistory extends Component{
  constructor(props) {
    super(props);
    this.state = {
      data: [
          {
            productName:"", image: "", productCost: "", sponsor:"", fee:"", address: "", status: ""
          } 
      ],
    }
    //binding functions for all helper functions 
    this.handleClick = this.handleClick.bind(this); 
    this.renderTableData = this.renderTableData.bind(this); 
  }
  //handles the log out from the application
  handleClick() {
    logout();
    this.props.history.push("/");
  }
  componentDidMount(){
    driver_purchase_history().then( res => {
    var info = [];
    console.log(res)
    res.data.purchases.forEach ( element => info.push(

      {
        productName: element.item.productName,
        image: element.item.image,
        productCost: element.item.productCost,
        sponsor: element.sponsor.username,
        fee: element.fee,
        address: element.address,
        status: element.status
        }));
      this.setState({data: info});
    });
  }  

  renderTableData() {
    return this.state.data.map((data, index) => {
        const {productName, productCost, image, sponsor, fee, address, status } = data //destructuring
        return (
          <tr key={productName}>
              <td className = "cartTextCenter"><img src = {image} height = "100" width = "100"/></td>
              <td>{productName}</td>
              <td >{productCost}</td>
              <td >{sponsor}</td>
              <td >{fee}</td>
              <td >{address}</td>
              <td >{status}</td>
          </tr>
          
        )
    })
  }

    render(){
        return(
          <div>
            <h1>Purchasing History</h1>
            <table className ="spaceTable">
            <thead>
	                <tr>
	                  <th>Image</th>
	                  <th>Name</th>
                    <th>Cost (Points)</th>
                    <th>sponsor</th>
                    <th>fee</th>
                    <th>address</th>
                    <th>status</th>
                    <th> </th>
	                </tr>
	              </thead> 
                <tbody>
                    {this.renderTableData()}
                </tbody>
              </table>
          </div>
          )        
    }
}
export default withRouter(PurchaseHistory);



