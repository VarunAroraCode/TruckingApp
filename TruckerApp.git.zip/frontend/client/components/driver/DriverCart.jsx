import React, { Component } from 'react';
//import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './driverHome.css'
import PurchaseItem from './PurchaseHistory.jsx'
import {driver_shop, related_shop} from '../backend/ebay.jsx';
import {driver_info, driver_cart_remove, driver_cart_buy} from '../backend/driver.jsx';
import DriverCartDisplay from "./DriverCartDisplay.jsx"


class DriverCart extends Component{
  constructor(props) {
    super(props);
    this.state = {
        data: [{image: "null",productName: '', productCost: null, productReviews: null, sponsor: ""}],
        userData: [{points:'', sponsor: ''}],
        currentSponsor: null,
        address: "",
        totalCost: "",
        checked: false,
        points: null,
        position: ""
    }
    //binding functions for all helper functions 
    this.handleSponsorSelect = this.handleSponsorSelect.bind(this);
    this.handleClick = this.handleClick.bind(this); 
    //this.renderTableData = this.renderTableData.bind(this);
    //this.RemoveItem = this.RemoveItem.bind(this); 
    //this.renderSponsorData = this.renderSponsorData.bind(this); 
    this.handleChange = this.handleChange.bind(this);
    //this.getTotalCost = this.getTotalCost.bind(this);
    //this.purchaseCart = this.purchaseCart.bind(this);
    
  }
  //handles the log out from the application
  handleClick() {
    logout();
    this.props.history.push("/");
  }
  componentDidMount(){
    // gets sponsors from database 
        //API CALL TO GET DRIVER SPECIFIC CART AND CATALOG DATA
    driver_shop().then( res => {
      var catalog = [];
      res.data.items.forEach( item => catalog.push(
        {
          image: item.image, 
          productName: item.productName,
          productCost: item.productCost,
          productReviews: item.productReviews,
          sponsor: item.sponsor
        }
        ));  
        console.log(catalog)
      this.setState({data:catalog});
    });
    //API CALL TO GET DRIVER SPECIFIC INFO
    driver_info().then( res => {
    var data = [];
    res.data.points.forEach(item => data.push ({
      sponsor: item.sponsor,
      points: item.points
    }));   
      
      this.setState({userData: data})
    });

  }
  handleChange(event) {
    this.setState({address: event.target.value});
  }
  //this generates code for the user to enter in their address once they're ready for checkout. 
  //once you enter your address, click purchase cart and you'll get approved or denied. 


  handleSponsorSelect(event){
    event.preventDefault()
    this.setState({currentSponsor: event.target.value})
  }


  render(){
    if(this.state.currentSponsor == null){
      return(
      <div>
        <header>
          <form>
            <label>
               Your Current Sponsors:
               <br/>
               Select Sponsor Whose Cart Your Wish To View:
                 {this.state.userData.map (name => (
                   <ul> 
                     {name.sponsor}
                     <Button className = "cartViewSponsor" value = {name.sponsor} onClick={this.handleSponsorSelect} >Select</Button>
                   </ul>
                 ))}
            </label>
          </form>
        </header>
      </div>
      )
    }
    else{
      return(
        <div >
          <DriverCartDisplay sponsorUsername={this.state.currentSponsor}></DriverCartDisplay>
        </div>
      ) 
  }
}
}
export default withRouter(DriverCart);

       