
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem } from 'react-bootstrap';
import { Route, Switch, Link, withRouter} from 'react-router-dom';
import {logout} from '../backend/auth.jsx';
import DriverCart from './DriverCart.jsx' ;
import DriverCatalog from './DriverCatalog.jsx';
import DriverSettings from './DriverSettings.jsx';
import DriverHomePage from './DriverHomePage.jsx';

class DriverHomeNav extends Component{
    
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
      }

      handleClick() {
	      logout();
	      this.props.history.push('/');
      }

      render() {
        return(
	    <div>
		<Navbar collapseOnSelect expand="lg" bg="light"  >
		    <Navbar.Collapse>	
		    <Navbar.Brand>
			<Nav.Link as={Link} to={this.props.match.url}>Trucking Rewards</Nav.Link>
		    </Navbar.Brand>
		    <Nav className="container-fluid">
			<Nav.Link as={Link} to={this.props.match.url}>Home</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/DriverApplication"}>Application</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/DriverCatalog"}>Catalog</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/DriverCart"}>Cart</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/PurchaseHistory"}>Purchase History</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/DriverSettings"}>Settings</Nav.Link>
			<Nav.Item className="ml-auto">
			    <Button onClick={this.handleClick}>Logout</Button>
			</Nav.Item>
		    </Nav>
		    </Navbar.Collapse>
		</Navbar>,
	    </div>	
        ) 
      }
}
export default withRouter(DriverHomeNav);
