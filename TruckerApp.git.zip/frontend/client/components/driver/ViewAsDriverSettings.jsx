import React, { Component } from 'react';
import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import {Container, Navbar, Nav, DropdownButton, Form, Button} from 'react-bootstrap';


class ViewAsDriverSettings extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
            first_name: "",
            last_name: "",
            password: "", 
            email: "",
            repassword: "",
            username:"",



        }
        this.handleClick = this.handleClick.bind(this);
      }
      handleClick() {
          logout();
	      this.props.history.push("/");
      }


      handleOnSubmit(event){
        alterDriver (this.state.username, this.state.email, 
            this.state.password, this.state.repassword, 
            this.state.first_name, this.state.last_name)
        .then(res => {
        if("success" in res["data"]){
          alert("account created");
        }else{
          alert("account failed to create");
        }
        });
      }


      render() {
        return(
          <div>
            <h1>Alter Your Profile:</h1>
            <Form.Group controlId="formFirstName">
                <Form.Label>First Name</Form.Label>
                <Form.Control type="text" placeholder="First Name"
              onChange = {(event,newValue) => this.setState({first_name:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formLastName">
                <Form.Label>Last Name</Form.Label>
                <Form.Control type="text" placeholder="Last Name"
              onChange = {(event,newValue) => this.setState({last_name:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formUsername">
                <Form.Label>Username</Form.Label>
                <Form.Control type="text" placeholder="Username"
              onChange = {(event,newValue) => this.setState({username:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formEmail">
                <Form.Label>Email</Form.Label>
                <Form.Control type="email" placeholder="Email"
              onChange = {(event,newValue) => this.setState({email:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Password"
              onChange = {(event,newValue) => this.setState({password:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formRepassword">
                <Form.Label>Password Check</Form.Label>
                <Form.Control type="password" placeholder="Password Check"
              onChange = {(event,newValue) => this.setState({repassword:event.target.value})}
                />
                </Form.Group>
                <br/>
            
                <Button label="Submit"  onClick={(event) => this.handleOnSubmit(event)}>Submit Changes</Button>
          </div>
             
        ) 
      }
}
export default withRouter(ViewAsDriverSettings);

