import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import {logout} from '../backend/auth.jsx';
import {driver_info} from '../backend/driver.jsx';
import {send_request} from '../backend/accounts.jsx';
import {withRouter} from 'react-router-dom';
import DriverCart from './DriverCart.jsx' ;
import DriverCatalog from './DriverCatalog.jsx';
import DriverSettings from './DriverSettings.jsx';
import DriverHomePage from './DriverHomePage.jsx';
import DriverApplication from './DriverApplication.jsx';
import DriverHomeNav from './DriverHomeNav.jsx';
import PurchaseHistory from './PurchaseHistory.jsx';


import  './driverHome.css';
//adding a comment to narrow down nginx bug
class DriverHome extends Component{
    constructor(props) {
      super(props);
      this.state = {
        username: props.passdownUsername,
        points : 0,
      }
      this.handleClick = this.handleClick.bind(this);
      }
      handleClick() {
        logout();
        this.props.history.push("/");
      }

      componentDidMount() {
        driver_info(this.props.passdownUsername).then( res => {
          console.log(res);
            this.setState({points:res.data['points']});
        });
      }

      render() {
        return(
        <div>
            <DriverHomeNav></DriverHomeNav>
        <Switch>
            <Route exact path={this.props.match.path}> <DriverHomePage driverUsername={this.state.username}/></Route>
            <Route path={this.props.match.path+"/DriverCatalog"}> <DriverCatalog/></Route>
            <Route path={this.props.match.path+"/DriverCart"} > <DriverCart />  </Route>
            <Route path={this.props.match.path+"/DriverSettings"} > <DriverSettings />  </Route>
            <Route path={this.props.match.path+"/DriverApplication"} > <DriverApplication />  </Route>
            <Route path={this.props.match.path+"/PurchaseHistory"} > <PurchaseHistory />  </Route>
            
        </Switch>
        </div>
        ) 
      }
}
export default withRouter(DriverHome);
