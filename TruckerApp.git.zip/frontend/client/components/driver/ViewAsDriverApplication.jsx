import React, { Component } from 'react';
import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './ViewAsdriverHome.css';
import {get_users, send_request} from '../backend/accounts.jsx';
import {alterDriver, driver_info} from '../backend/driver.jsx';

class ViewAsDriverApplication extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
		      sponsorList: [{sponsorName:""}],
          userData: [{points:'', sponsor: ''}]
        }
       

        this.handleClick = this.handleClick.bind(this);
        this.renderTableData = this.renderTableData.bind(this);
      }

      handleClick() {
          logout();
	  this.props.history.push("/");
      }

    componentDidMount(){
	// gets sponsors from database 
    	get_users('S',this.props.passDownUsername).then( res => {
      var sponsors = [];
      res.data.users.forEach( user => sponsors.push({sponsorName: user.username}));
      this.setState({sponsorList:sponsors});
      });

      driver_info().then( res => {
        var data = [];
        res.data.points.forEach(item => data.push ({
          sponsor: item.sponsor,
          points: item.points
        }));   
        this.setState({userData: data})
      });
    }

    renderTableData() {
      //if(drivers)
      return this.state.sponsorList.map((data, index) => {
          const { sponsorName } = data //destructuring
          return (
            <tr key={sponsorName}>
                <td>{sponsorName}</td>
                <td><Button value={sponsorName} onClick={e => send_request(e.target.value) } >Apply</Button></td>
            </tr>
            
          )
          
      })
    }

    renderTableHeader() {
      let header = Object.keys(this.state.sponsorList[0]);
      return header.map((key, index) => {
         return <th key={index}>{key.toUpperCase()}</th>
      })
   }
      render(){
        return(
          <div >
             <header >
            <h1>Available Sponsors:</h1>   
            <table>
                 <tbody>
                     <tr>{this.renderTableHeader()}</tr>
                    {this.renderTableData()}
                 </tbody>
              </table>
          </header>
          </div>
            
        ) 
      }
}
export default withRouter(ViewAsDriverApplication);

