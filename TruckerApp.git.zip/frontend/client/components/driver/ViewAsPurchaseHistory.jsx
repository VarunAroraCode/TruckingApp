import React, { Component } from 'react';
//import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './driverHome.css'
import {driver_shop, related_shop} from '../backend/ebay.jsx';
import {driver_purchase_history} from '../backend/driver.jsx';



class ViewAsPurchaseHistory extends Component{
  constructor(props) {
    super(props);
    this.state = {
      data: [{}],
      address: ""
    }
    //binding functions for all helper functions 
    this.handleClick = this.handleClick.bind(this); 
    this.renderTableData = this.renderTableData.bind(this); 
  }
  //handles the log out from the application
  handleClick() {
    logout();
    this.props.history.push("/");
  }
  componentDidMount(){
    driver_purchase_history(this.props.passDownUsername).then( res => {
    var info = [];
    res.data.points.forEach ( item => info.push(
      {
        sponsor: item.sponsor,
        points: item.points
      }));
          this.setState({data: info});
          });
        }  

  renderTableData() {
    return this.state.data.map((data, index) => {
  if(data.sponsor == this.state.currentSponsor){
        const { image, productName, productCost, productReviews, sponsor } = data //destructuring
        return (
          <tr key={productName}>
              <td className = "cartTextCenter"><img src = {image} height = "100" width = "100"/></td>
              <td>{productName}</td>
              <td >{productCost}</td>
              <td >{productReviews}</td>
              <Button  onClick={() => this.AddItem(productName, productCost, productReviews, sponsor, image)}>Add Item</Button>
          </tr>
          
        )}
    })
  }

    render(){
        return(
          <div>
            HELLOO
            <form>
              <label>
                Enter the address you want these items delivered:
                <textarea value={this.state.address} onChange={this.handleChange} />
              </label>
              <input type="submit" value="Purchase Cart" />
            </form>
          </div>
          )        
    }
}
export default withRouter(ViewAsPurchaseHistory);



