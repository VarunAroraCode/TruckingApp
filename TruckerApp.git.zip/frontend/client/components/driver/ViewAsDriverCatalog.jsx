import React, { Component } from 'react';
//import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './ViewAsdriverHome.css'
import {driver_shop, related_shop} from '../backend/ebay.jsx';
import {driver_info, driver_cart_add} from '../backend/driver.jsx';



class ViewAsDriverCatalog extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
            data: [
                {image: "null",productName: '', productCost: null, productReviews: null, sponsor: ""}],
		        userData: [{points:'', sponsor: ''}],
            currentSponsor: null,
            checked: false,
        }
        //binding functions for all helper functions 
        this.handleSponsorSelect = this.handleSponsorSelect.bind(this);
        this.handleClick = this.handleClick.bind(this); 
        this.renderTableData = this.renderTableData.bind(this);
        this.AddItem = this.AddItem.bind(this); 
      }
      //handles the log out from the application
      handleClick() {
        logout();
	      this.props.history.push("/");
      }

      AddItem(name, cost, reviews, sponsor, img, ){
        driver_cart_add(sponsor, name, img, cost, reviews,this.props.passDownUsername)
        console.log('item added')
        }
  

      componentDidMount(){
        // gets sponsors from database 
        related_shop(this.props.passDownUsername).then( res => {
          var catalog = [];
          res.data.items.forEach( item => catalog.push(
            {
              image: item.image, 
              productName: item.productName,
              productCost: item.productCost,
              productReviews: item.productReviews,
              sponsor: item.sponsor
            }
            ));  
          this.setState({data:catalog});
        });
	driver_info(this.props.passDownUsername,this.props.passDownUsername).then( res => {
		var data = [];
		res.data.points.forEach(item => data.push ({
			sponsor: item.sponsor,
			points: item.points
		}));   
      this.setState({userData: data})
	});
      }

      
    renderTableData() {
      return this.state.data.map((data, index) => {
	  if(data.sponsor == this.state.currentSponsor){
          const { image, productName, productCost, productReviews, sponsor } = data //destructuring
          return (
            <tr key={productName}>
                <td className = "cartTextCenter"><img src = {image} height = "100" width = "100"/></td>
                <td>{productName}</td>
                <td >{productCost}</td>
                <td >{productReviews}</td>
                <Button  onClick={() => this.AddItem(productName, productCost, productReviews, sponsor, image)}>Add Item</Button>
            </tr>
            
          )}
      })
    }

    handleSponsorSelect(event){
      event.preventDefault()
      this.setState({currentSponsor: event.target.value})
      console.log(this.state.currentSponsor)
    }

    renderTableHeader() {
      let header = Object.keys(this.state.data[0])
      return header.map((key, index) => {
         return <th key={index}>{key.toUpperCase()}</th>
      })
   }
      render(){


        if(this.state.currentSponsor == null){
          return(
 
          <div>
            <header>
              <form>
                <label>
                   Your Current Sponsors:
                   <br/>
                   Select Sponsor Whose Catalog Your Wish To View:
                     {this.state.userData.map (name => (
                       <ul> 
                         {name.sponsor}
                         <Button className = "cartViewSponsor" value = {name.sponsor} onClick={this.handleSponsorSelect} >Select</Button>
                       </ul>
                     ))}
                </label>
              </form>
            </header>
          </div>
          )
        }
        else{
          return(
            <div >
              <header>
                <h1>Current Catalog available for purchase:</h1>  
                <h3 className = "PointNameAlign">Points Available: 
                  <br/>
                  <h3 className = "PointValueAlign">{this.state.points}</h3>
                </h3>
                </header> 
                <table className ="spaceTable">
                <thead>
	                <tr>
	                  <th>Image</th>
	                  <th>Name</th>
                    <th>Cost (Points)</th>
                    <th>Reviews</th>
                    <th> </th>
	                </tr>
	              </thead> 
                    <tbody>
                        {/* <tr>{this.renderTableHeader()}</tr> */}
                        {this.renderTableData()}
                    </tbody>
                  </table>
              {/* <div className = "DriverCartSubmitButton">
                <Button onClick={this.AddItem} >Add Items To Cart</Button>
              </div> */}
            </div>
          ) 
      }
    }
}
export default withRouter(ViewAsDriverCatalog);

