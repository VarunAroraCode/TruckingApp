import React, { Component } from 'react';
//import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './driverHome.css'
import {driver_shop, related_shop} from '../backend/ebay.jsx';
import {driver_info, driver_cart_remove, driver_cart_buy} from '../backend/driver.jsx';


class DriverCartDisplay extends Component{
  constructor(props) {
    super(props);
    this.state = {
        data: [{image: "null",productName: '', productCost: null, productReviews: null, sponsor: ""}],
        userData: [{points:'', sponsor: ''}],
        currentSponsor: this.props.sponsorUsername,
        address: "",
        totalCost: "",
        checked: false,
        points: null,
        position: ""
    }
    //binding functions for all helper functions 
    this.handleClick = this.handleClick.bind(this); 
    this.renderTableData = this.renderTableData.bind(this);
    this.RemoveItem = this.RemoveItem.bind(this); 
    this.renderSponsorData = this.renderSponsorData.bind(this); 
    this.handleChange = this.handleChange.bind(this);
    this.getTotalCost = this.getTotalCost.bind(this);
    this.purchaseCart = this.purchaseCart.bind(this);
    
  }
  //handles the log out from the application
  handleClick() {
    logout();
    this.props.history.push("/");
  }
  componentDidMount(){
    // gets sponsors from database 
        //API CALL TO GET DRIVER SPECIFIC CART AND CATALOG DATA
    driver_shop().then( res => {
      var catalog = [];
      res.data.items.forEach( item => catalog.push(
        {
          image: item.image, 
          productName: item.productName,
          productCost: item.productCost,
          productReviews: item.productReviews,
          sponsor: item.sponsor
        }
        ));  
        console.log(catalog)
      this.setState({data:catalog});
    });
    //API CALL TO GET DRIVER SPECIFIC INFO
    driver_info().then( res => {
    var data = [];
    res.data.points.forEach(item => data.push ({
      sponsor: item.sponsor,
      points: item.points
    }));   
      
      this.setState({userData: data})
    });

  }
  RemoveItem(name, cost, reviews, sponsor, img){
    driver_cart_remove(sponsor, name, img, cost, reviews)
    driver_shop().then( res => {
        var catalog = [];
        res.data.items.forEach( item => catalog.push(
          {
            image: item.image, 
            productName: item.productName,
            productCost: item.productCost,
            productReviews: item.productReviews,
            sponsor: item.sponsor
          }
          ));  
          console.log(catalog)
        this.setState({data:catalog});
      });
    console.log('item removed')
    
    }

  handleChange(event) {
    this.setState({address: event.target.value});
  }
  //this generates code for the user to enter in their address once they're ready for checkout. 
  //once you enter your address, click purchase cart and you'll get approved or denied. 

  renderSponsorData() {
    return this.state.userData.map((data, index) => {
    if(data.sponsor == this.state.currentSponsor){

      const { points, sponsor } = data //destructuring
      this.state.points = points
      return (
      <tr key={sponsor}>
      <td>
      Sponsor Name: {sponsor} <br/> 
      Available Points: {points} <br/>
       <br/> <br/>
          </td>
        </tr>
      )
      }})
   }


  getTotalCost(){
    var cost = 0
    // console.log("GET TOTAL COST CONSOLE LOG POINTS :   " + this.state.points)
    this.state.data.map((data, index) => {
      if(data.sponsor == this.state.currentSponsor){
        cost += Number(Math.ceil(data.productCost))
        console.log(cost)
        this.setState({totalCost: cost})
      }
    })
  }
  purchaseCart(){
    console.log("user points:   " + this.state.points)
    if(this.state.totalCost == ""){
      alert("Please calculate the total cost before purchasing")
    }
    if(this.state.points < this.state.totalCost){
      alert("You do not have enough points to purchase this cart. Please remove items or select new ones")
    }
    if(this.state.points > this.state.totalCost){
      driver_cart_buy(this.state.currentSponsor, this.state.address)
      driver_shop().then( res => {
        var catalog = [];
        res.data.items.forEach( item => catalog.push(
          {
            image: item.image, 
            productName: item.productName,
            productCost: item.productCost,
            productReviews: item.productReviews,
            sponsor: item.sponsor
          }
          ));  
          console.log(catalog)
        this.setState({data:catalog});
      });
    }

  }
  
renderTableData() {
  return this.state.data.map((data, index) => {
  if(data.sponsor == this.state.currentSponsor){
      const { image, productName, productCost, productReviews, sponsor } = data //destructuring
      return (
        <tr key={productName}>
            <td className = "cartTextCenter"><img src = {image} height = "100" width = "100"/></td>
            <td className = "cartTextCenter">{productName}</td>
            <td className = "cartTextCenter">{productCost}</td>
            <td className = "cartTextCenter">{productReviews}</td>
            <Button  onClick={() => this.RemoveItem(productName, productCost, productReviews, sponsor, image)}>Remove Item</Button>
        </tr>
      )}
      
    })
}
  render(){
      return(
        <div >
          <header>
            <h1>Current Catalog available for purchase:</h1>  
            <h3><table>
                 <tbody>
                    {this.renderSponsorData()}
                 </tbody>
              </table></h3>
            </header> 
            <table className ="spaceTable">
            <thead>
	                <tr>
	                  <th>Image</th>
	                  <th>Name</th>
                    <th>Cost (Points)</th>
                    <th>Reviews</th>
                    <th> </th>
	                </tr>
	              </thead> 
                <tbody>
                    {this.renderTableData()}
                </tbody>
              </table>
              
              <h1>Total cost: {this.state.totalCost}</h1>
            <Button onClick={this.getTotalCost} >Calculate Total Cost</Button>
            <Button onClick={this.purchaseCart} >Purchase Cart</Button>
        </div>
      ) 
  }
}

export default withRouter(DriverCartDisplay);

       