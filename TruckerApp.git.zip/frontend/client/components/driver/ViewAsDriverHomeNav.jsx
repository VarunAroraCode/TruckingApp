
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem } from 'react-bootstrap';
import { Route, Switch, Link, withRouter} from 'react-router-dom';
import {logout} from '../backend/auth.jsx';
import ViewAsDriverCart from './ViewAsDriverCart.jsx' ;
import ViewAsDriverCatalog from './ViewAsDriverCatalog.jsx';
import ViewAsDriverSettings from './ViewAsDriverSettings.jsx';
import ViewAsDriverHomePage from './ViewAsDriverHomePage.jsx';

class ViewAsDriverHomeNav extends Component{
    
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
      }

      handleClick() {
	      logout();
	      this.props.history.push('/');
      }

      render() {
        return(
	    <div>
		<Navbar collapseOnSelect expand="lg" bg="light"  >
		    <Navbar.Collapse>	
		    <Navbar.Brand>
			<Nav.Link as={Link} to={this.props.match.url}>Trucking Rewards</Nav.Link>
		    </Navbar.Brand>
		    <Nav className="container-fluid">
			<Nav.Link as={Link} to={this.props.match.url}>Home</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/ViewAsDriverApplication"}>Application</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/ViewAsDriverCatalog"}>Catalog</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/ViewAsDriverCart"}>Cart</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/ViewAsPurchaseHistory"}>Purchase History</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/ViewAsDriverSettings"}>Settings</Nav.Link>
			<Nav.Link as={Link} to={"/SponsorHome"}>Exit View As</Nav.Link>
			<Nav.Item className="ml-auto">
			    <Button onClick={this.handleClick}>Logout</Button>
			</Nav.Item>
		    </Nav>
		    </Navbar.Collapse>
		</Navbar>,
	    </div>	
        ) 
      }
}
export default withRouter(ViewAsDriverHomeNav);
