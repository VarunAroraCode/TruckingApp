
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link, withRouter } from 'react-router-dom';
import AdminInspectSponsor from './AdminInspectSponsor.jsx';
import "./Admin.css";
import {ReactPaginate as Paginate} from 'react-paginate';
import {alterDriver} from '../backend/driver.jsx';
//TODO: NOT THE REAL ADMIN SETTINGS PAGE, THIS IS JUST FILLER UNTIL A REAL SETTINGS PAGE IS MADE AND WILL BE COPIED OVER HERE

class AdminSettings extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
          first_name: "",
          last_name: "",
          password: "", 
          email: "",
          repassword: "",
          username:"",
        }    
      }
      handleOnSubmit(event){
        alterDriver (this.state.username, this.state.email, 
            this.state.password, this.state.repassword, 
            this.state.first_name, this.state.last_name)
        .then(res => {
        if("success" in res["data"]){
          alert("account created");
        }else{
          alert("account failed to create");
        }
        });
      }
        
      render() {
        return(
          <div>
            <h1>Alter {this.props.passDownUserName}'s Profile </h1>
            <Form.Group controlId="formFirstName">
                <Form.Label>Update First Name</Form.Label>
                <Form.Control type="text" placeholder="First Name"
              onChange = {(event,newValue) => this.setState({first_name:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formLastName">
                <Form.Label>Update Last Name</Form.Label>
                <Form.Control type="text" placeholder="Last Name"
              onChange = {(event,newValue) => this.setState({last_name:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formUsername">
                <Form.Label>Update Username</Form.Label>
                <Form.Control type="text" placeholder="Username"
              onChange = {(event,newValue) => this.setState({username:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formEmail">
                <Form.Label>Update Email</Form.Label>
                <Form.Control type="email" placeholder="Email"
              onChange = {(event,newValue) => this.setState({email:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formPassword">
                <Form.Label>Update Password</Form.Label>
                <Form.Control type="password" placeholder="Password"
              onChange = {(event,newValue) => this.setState({password:event.target.value})}
                />
                </Form.Group>
            <br/>
            <Form.Group controlId="formRepassword">
                <Form.Label>Reconfirm Password</Form.Label>
                <Form.Control type="password" placeholder="Password Check"
              onChange = {(event,newValue) => this.setState({repassword:event.target.value})}
                />
                </Form.Group>
                <br/>
            
                <Button label="Submit"  onClick={(event) => this.handleOnSubmit(event)}>Submit Changes</Button>
          </div>
        ) 
      }
}
export default withRouter(AdminSettings);