
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link, withRouter } from 'react-router-dom';
import './Admin.css';
import AdminSettings from './AdminSettings.jsx';
//import './AdminInspectAdmin.css';
//TODO: Rename file

class AdminInspectAdmin extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
          first_name: "",
          last_name: "",
          password: "", 
          email: "",
          repassword: "",
          username:"",
          editing:false
        }
        this.handleClick = this.handleClick.bind(this);
        this.handleEdit = this.handleEdit.bind(this);
        this.handleStopEdit = this.handleStopEdit.bind(this);
      }
      handleClick() {
        console.log('Click happened');
        coseole.log(this.props.page);
      }
      handleEdit(){
        console.log("editing is: " + this.state.editing)
        this.setState({editing:true})
        console.log("editing is: " + this.state.editing)
      }
      handleStopEdit(){
        console.log("editing is: " + this.state.editing)
        this.setState({editing:false})
        console.log("editing is: " + this.state.editing)
      }
      render() {
        if(this.state.editing == false){
        return(
            <div>
              <header className = "AdminInspectDriver-header">
                <h1>{this.props.passDownUserName}</h1>
                  <button onClick={this.handleEdit}>edit profile</button>
              </header>
            </div>
        )
        }
        else{
          return(
              <div>
                <header className = "AdminInspectDriver-header">
                  <h1>{this.props.passDownUserName}</h1>
                    <button onClick={this.handleStopEdit}>stop editing profile</button>
                    <AdminSettings></AdminSettings>
                    
                </header>
              </div>
          )
        }
      }
}
export default withRouter(AdminInspectAdmin)