import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link, withRouter} from 'react-router-dom';
import './Admin.css';
import { driver_info } from '../backend/driver.jsx';
import AdminSettings from './AdminSettings.jsx';
import {admin_reports} from '../backend/accounts.jsx';
//import './AdminReports.css';
//TODO: Pull relevent info, 
//TODO: add a edit profile button, driver information should be passed to the editprofile component from here
//TODO: display list of all sponsors a driver has

class AdminReports extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
            inputvalue:"",
            reportType:"",
             inspected_username:"",
            start_date:"",
            end_date:"",
            reports:[{sponsor:"",driver:"",cost:0.0,item:"",status:""}],
        }
        this.renderFilterBar = this.renderFilterBar.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.renderFilterOptions = this.renderFilterOptions.bind(this);
        this.getReports = this.getReports.bind(this);
        this.renderSales = this.renderSales.bind(this);
        this.renderSalesTableData = this.renderSalesTableData.bind(this);
      }
      componentDidMount() {
          console.log("hello there")
      }
      handleChange(event) {
        this.setState({reportType: event.target.value});
      }
      handleUserNameChange(event) {
        this.setState({inspected_username: event.target.value});
        console.log("username being changed")
      }
      handleDateStartChange(event) {
        this.setState({start_date: event.target.value});
      }
      handleDateEndChange(event) {
        this.setState({end_date: event.target.value});
      }
      getReports(){
        admin_reports(this.state.inspected_username).then(res => { 
            var purchase_list = [];
            console.log(res)
            res.data.purchases.forEach( purchase => purchase_list.push(
              {
                sponsor: purchase.sponsor.username,
                driver: purchase.driver.username,
                cost: purchase.fee * 100,
                item: purchase.item.productName,
                status: purchase.status
              }));
              console.log(purchase_list)
              this.setState({reports:purchase_list});
            })
      }
      renderFilterBar(){
          return(
            <div>
                <h1>
                    <label>
                        Report type: 
                        <select value={this.state.reportType} onChange={this.handleChange}>
                            <option value="">----</option>
                            <option value="SBS">Sales By Sponsor</option>
                            <option value="SBD">Sales By Driver</option>
                            <option value="I">Invoice</option>
                            <option value="AL">Audit Log</option>
                        </select>
                    </label>
                </h1>
                <h2>
                    {this.renderFilterOptions()}
                </h2>
            </div>
          )
      }
      renderFilterOptions(){
          return(
            <div>
                <form>
                    <input
                        type='text'
                        onChange={this.handleUserNameChange}
                    />
                </form>
                <p>
                    Start Date
                    <input type='text' onChange={this.handleDateStartChange} value="mm/dd/yyyy">
                    </input>
                </p>
                <p>
                    End Date
                    <input type='text' onChange={this.handleDateEndChange} value="mm/dd/yyyy">
                    </input>
                </p>
            </div>
          )
      }
      renderSales(){
          return(
              <div>
                  <table className="spaceTable">
                    <thead>
	                    <tr>
	                        <th>Sponsor</th>
	                        <th>Driver</th>
                            <th>Cost</th>
                            <th>Item</th>
                            <th>Status</th>
	                    </tr>
	                </thead>
                    <tbody>
                        {this.renderSalesTableData()}
                    </tbody>
                  </table> 
              </div>
          )
      }
      renderSalesTableData() {
        //if(drivers)
        return this.state.reports.map((reports, index) => {
            const {sponsor,driver,cost,item,status} = reports //destructuring
            //console.log(driver)
            return (
              <tr key={sponsor}>
                  <td>{sponsor}</td>
                  <td>{driver}</td>
                  <td>{cost}</td>
                  <td>{item}</td>
                  <td>{status}</td>
              </tr>
            )  
        })
      }
      render() {
        // this.handleUpkeep()
        if(this.state.reportType == ""){
            return(
                <div>
                    <button onClick={this.getReports}>Generate Report</button>
                    {this.renderFilterBar()}
                    {console.log(this.state.reportType)}
                </div>
            )
        }
        if(this.state.reportType == "SBS"){
            return(
                <div>
                    <button onClick={this.getReports}>Generate Report</button>
                    {this.renderFilterBar()}
                    {console.log(this.state.reportType)}
                    {this.renderSales()}
                </div>
            )
        }
        if(this.state.reportType == "SBD"){
            return(
                <div>
                    <button onClick={this.getReports}>Generate Report</button>
                    {this.renderFilterBar()}
                    {console.log(this.state.reportType)}
                    {this.renderSales()}   
                </div>
            )
        }
        if(this.state.reportType == "I"){
            return(
                <div>
                    <button onClick={this.getReports}>Generate Report</button>
                    {this.renderFilterBar()}
                    {console.log(this.state.reportType)}
                    invoice
                </div>
            )
        }
        if(this.state.reportType == "AL"){
            return(
                <div>
                    <button onClick={this.getReports}>Generate Report</button>
                    {this.renderFilterBar()}
                    {console.log(this.state.reportType)}
                    audit logs
                </div>
            )
        }
    }
}
export default withRouter(AdminReports)