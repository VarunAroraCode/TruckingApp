
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link, withRouter } from 'react-router-dom';
import AdminInspectDriver from './AdminInspectDriver.jsx';
import "./Admin.css";
import {ReactPaginate as Paginate} from 'react-paginate';
import {get_requests, get_users, admin_get_driver_info} from '../backend/accounts.jsx';

//TODO: find a way to pass user specific info to the inpsectSponsor page. Probably has to do with state variables
//TODO: add a edit profile button, driver information should be passed to the editprofile component from here

class AdminViewDrivers extends Component{
    
    constructor(props) {
        super(props);
        this.state = { //state is by default an object
          myDrivers: [
            {userName:"", firstName:"",lastName:""}
          ],
          currentDriver: "default",
          connected_sponsors: [{sponsorname:"",rate:""}]
       }
        this.handleClick = this.handleClick.bind(this);
        this.renderTableData = this.renderTableData.bind(this);
        this.renderTableHeader = this.renderTableHeader.bind(this);
        this.handleInspect = this.handleInspect.bind(this);
        this.handleDriverSelect = this.handleDriverSelect.bind(this);
      }
      handleClick() {
        console.log('Click happened');
        coseole.log(this.props.page);
      }

      handleInspect(event){
        this.props.history.push("/AdminInspectDriver");
      }

      renderTableData() {
        //if(drivers)
        return this.state.myDrivers.map((user, index) => {
           const { userName, firstName, lastName } = user //destructuring
           return (
              <tr key={index}>
                 {/* <td>{id}</td> */}
                 <td>
                    <Link 
                      to={this.props.match.url+"/AdminInspectDriver"}
                      value={userName}
                      onClick={() => this.handleDriverSelect(userName)}>
                      {userName}
                    </Link>
                  </td>
                 <td>{firstName}</td>
                 <td>{lastName}</td>
                 {/* <td>{Change}</td>  */}
              </tr>
           )
        })
      }

      renderTableHeader() {
        let header = Object.keys(this.state.myDrivers[0])
        return header.map((key, index) => {
            return <th key={index}>{key.toUpperCase()}</th>
        })
      }
      handleDriverSelect(value){
        this.setState({currentDriver: value})
        console.log("current driver is: " + this.state.currentDriver)
        //getting sponsor info to pass down to inspect
        admin_get_driver_info(value).then(res => { 
          var drivers_sponsors = [];
          console.log(res)
          res.data.sponsors.forEach( sponsor => drivers_sponsors.push(
            {
              sponsorname: sponsor.account.username,
              rate: sponsor.points_to_cents
            }));
            console.log(drivers_sponsors)
            this.setState({connected_sponsors:drivers_sponsors});
        })
      }

      componentDidMount(){
        // gets sponsors from database 
          get_users('D').then( res => {
          var drivers = [];
          console.log(res)
          res.data.users.forEach( user => drivers.push(
            {
              userName: user.username,
              firstName: user.first_name,
              lastName: user.last_name
            }));
          this.setState({myDrivers:drivers});
          //console.log(sponsors)
          });
          // console.log(this.state.myAdmins)
      }
        
      render() {
        return(
            <div className='DriverList'>
              <header className>
                <h1 className='title'>Drivers</h1>   
                  <table className='drivers'>
                    <tbody className='table'>
                      <tr>{this.renderTableHeader()}</tr>
                      {this.renderTableData()}
                    </tbody>
                  </table>
              </header>
              <Switch>
              <Route 
                  path={this.props.match.url+"/AdminInspectDriver"} 
                  render={() =><AdminInspectDriver 
                    passDownUserName = {this.state.currentDriver} 
                    passDownConnectedSponsors = {this.state.connected_sponsors} 
                  />}>
              </Route>
              </Switch>
            </div>
        ) 
      }
}
export default withRouter(AdminViewDrivers);