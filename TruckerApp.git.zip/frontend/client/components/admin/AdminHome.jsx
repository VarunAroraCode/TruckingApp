import './Admin.css';
import React, { Component } from 'react';
import { Route, Switch, Link, withRouter} from 'react-router-dom';
import AdminViewSponsors from './AdminViewSponsors.jsx';
import AdminHomeNav from './AdminHomeNav.jsx';
import AdminViewDrivers from './AdminViewDrivers.jsx';
import AdminViewAdmin from './AdminViewAdmin.jsx';
import AdminSettings from './AdminSettings.jsx';
import ViewAsDriverHome from '../driver/ViewAsDriverHome.jsx';
import ViewAsSponsorHome from '../sponsor/ViewAsSponsorHome.jsx';
import AdminReports from './AdminReports.jsx';
import {get_requests, get_users} from '../backend/accounts.jsx';
import { driver_info } from '../backend/driver.jsx';
import Register from '../Register.jsx';

class AdminHome extends Component{
    
    constructor(props) {
        super(props);
		this.state = {
            first_name: "",
            repassword: "",
            username:"",
        }
      }
	  componentDidMount() {
		//TODO: get a admin_info and sponsor_info working
        // get_requests(true).then(res => {
        //   console.log(res);
        // });
     	//get_users('A').then( res =>{ console.log(res);} );
		//driver_info(this.props.passdownUsername).then(res => {console.log(res)})
		this.setState({username:this.props.passdownUsername})
		//console.log("state.username: " + this.state.username)
      }


      render() {
        return(
		<div>
	    	<AdminHomeNav></AdminHomeNav>
			{console.log("state.username: " + this.state.username)}	
		<Switch>
		    <Route exact path={this.props.match.path}> Welcome Admin {this.props.passdownUsername} !</Route>
		    <Route path={this.props.match.path+"/AdminViewSponsors"}> <AdminViewSponsors/></Route>
		    <Route path={this.props.match.path+"/AdminViewDrivers"} > <AdminViewDrivers /></Route>
			<Route path={this.props.match.path+"/AdminViewAdmin"} > <AdminViewAdmin /></Route>
			<Route path={this.props.match.path+"/AdminSettings"} > 
				<AdminSettings
					passDownUserName = {this.state.username} 
				/>
			</Route>
			<Route path={this.props.match.path+"/AdminReports"} > <AdminReports /></Route>
			<Route path={"/ViewAsSponsorHome"}><ViewAsSponsorHome/></Route>
			<Route path={"/ViewAsDriverHome"}><ViewAsDriverHome/></Route>
			<Route path={this.props.match.path+"/AdminRegister"}> <Register /></Route>
		</Switch>
		</div>
        ) 
      }
}
export default withRouter(AdminHome);
