
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link, withRouter } from 'react-router-dom';
import './Admin.css';
import AdminSettings from './AdminSettings.jsx';
//import './AdminInspectSponsor.css';
//TODO: Settings page add link to 
//TODO: Display current sponsors list of all drivers

class AdminInspectSponsor extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
          first_name: "",
          last_name: "",
          password: "", 
          email: "",
          repassword: "",
          username:"",
          editing:false
        }
        this.handleClick = this.handleClick.bind(this);
        this.handleEdit = this.handleEdit.bind(this);
        this.handleStopEdit = this.handleStopEdit.bind(this);
        this.renderTableData = this.renderTableData.bind(this);
        this.renderTableHeader = this.renderTableHeader.bind(this);
      }
      handleClick() {
        console.log('Click happened');
        console.log(this.props.page);
      }
      handleEdit(){
        console.log("editing is: " + this.state.editing)
        this.setState({editing:true})
        console.log("editing is: " + this.state.editing)
      }
      handleStopEdit(){
        console.log("editing is: " + this.state.editing)
        this.setState({editing:false})
        console.log("editing is: " + this.state.editing)
      }
      renderTableData() {
        //if(drivers)
        return this.props.passDownConnectedDrivers.map((driver, index) => {
           const {drivername, points } = driver //destructuring
           return (
              <tr key={index}>
                 {/* <td>{id}</td> */}
                 <td>{drivername}</td>
                 <td>{points}</td>
                 {/* <td>{Change}</td>  */}
              </tr>
           )
        })
      }
      renderTableHeader() {
        let header = Object.keys(this.props.passDownConnectedDrivers[0])
        return header.map((key, index) => {
            return <th key={index}>{key.toUpperCase()}</th>
        })
      }
      render() {
        if(this.state.editing == false){
        return(
            <div>
              <header className = "AdminInspectDriver-header">
                <h1>{this.props.passDownUserName}</h1>
                  <table className='drivers'>
                    <tbody className='table'>
                      <tr>{this.renderTableHeader()}</tr>
                      {this.renderTableData()}
                    </tbody>
                  </table>
                  <button onClick={this.handleEdit}>edit profile</button>
              </header>
            </div>
        )
        }
        else{
          return(
              <div>
                <header className = "AdminInspectDriver-header">
                  <h1>{this.props.passDownUserName}</h1>
                    <button onClick={this.handleStopEdit}>stop editing profile</button>
                    <AdminSettings></AdminSettings>    
                </header>
              </div>
          )
        }
      }
}
export default withRouter(AdminInspectSponsor)