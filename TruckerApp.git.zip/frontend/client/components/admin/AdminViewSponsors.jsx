
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link, withRouter } from 'react-router-dom';
import AdminInspectSponsor from './AdminInspectSponsor.jsx';
import "./Admin.css";
import {ReactPaginate as Paginate} from 'react-paginate';
import {get_requests, get_users, admin_get_sponsor_info} from '../backend/accounts.jsx';
//TODO: make the table portion collapsable/ with scroll bar so that it does not render all users at once
//TODO: find a way to pass user specific info to the inpsectSponsor page. Probably has to do with state variables

class AdminViewSponsors extends Component{
    
    constructor(props) {
        super(props);
        this.state = { //state is by default an object
          mySponsors: [
            {userName:"", firstName:"",lastName:""}
          ],
          connected_drivers: [{drivername:"",points:""}],
          currentSponsor: "default"
       }
        this.handleClick = this.handleClick.bind(this);
        this.renderTableData = this.renderTableData.bind(this);
        this.renderTableHeader = this.renderTableHeader.bind(this);
        this.handleSponsorSelect = this.handleSponsorSelect.bind(this);
      }
      handleClick() {
        console.log('Click happened');
        coseole.log(this.props.page);
      }

      handleInspect(event){
        this.props.history.push("/AdminInspectSponsor");
      }

      handleSponsorSelect(value){
        this.setState({currentSponsor: value})
        console.log(this.state.currentSponsor)
        //getting drivers associated with this sponsor
        admin_get_sponsor_info(value).then(res => { 
          var sponsors_drivers = [];
          console.log(res)
          res.data.points.forEach( driver => sponsors_drivers.push(
            {
              drivername: driver.account.username,
              points: driver.points
            }));
            console.log(sponsors_drivers)
            this.setState({connected_drivers:sponsors_drivers});
        })
      }

      renderTableData() {
        //if(drivers)
        return this.state.mySponsors.map((user, index) => {
           const { userName, firstName, lastName } = user //destructuring
           return (
              <tr key={index}>
                 {/* <td>{id}</td> */}
                 <td>
                    <Link 
                      to={this.props.match.url+"/AdminInspectSponsors"}
                      value={userName}
                      onClick={() => this.handleSponsorSelect(userName)}>
                      {userName}
                    </Link>
                  </td>
                 <td>{firstName}</td>
                 <td>{lastName}</td>
                 {/* <td>{Change}</td>  */}
              </tr>
           )
        })
      }

      renderTableHeader() {
        let header = Object.keys(this.state.mySponsors[0])
        return header.map((key, index) => {
            return <th key={index}>{key.toUpperCase()}</th>
        })
      }

      customlog(){
        cosoloe.log("hello!")
      }

      componentDidMount(){
        // gets sponsors from database 
          get_users('S').then( res => {
          var sponsors = [];
          console.log(res.data.users)
          res.data.users.forEach( user => sponsors.push(
            {
              userName: user.username,
              firstName: user.first_name,
              lastName: user.last_name
            }));
          this.setState({mySponsors:sponsors});
          //console.log(sponsors)
          });
          // console.log(this.state.myAdmins)
      }
        
      render() {
        return(
            <div>
              {/* ------
              {console.log(this.state.mySponsors)}
              {this.state.mySponsors[0].sponsorName}
              ------ */}
              <header>
                <h1 className='title'>Sponsors</h1>   
                  <table className='drivers'>
                    <tbody className='table'>
                      <tr>{this.renderTableHeader()}</tr>
                      {this.renderTableData()}
                    </tbody>
                  </table>
              </header>
              <Switch>
                <Route 
                  path={this.props.match.url+"/AdminInspectSponsors"} 
                  render={() =><AdminInspectSponsor
                    passDownUserName = {this.state.currentSponsor}
                    passDownConnectedDrivers = {this.state.connected_drivers}
                  />}>
                </Route>
              </Switch>
            </div>
        ) 
      }
}
export default withRouter(AdminViewSponsors);