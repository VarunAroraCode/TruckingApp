
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link, withRouter } from 'react-router-dom';
import AdminInspectAdmin from './AdminInspectAdmin.jsx';
import "./Admin.css";
import {ReactPaginate as Paginate} from 'react-paginate';
import {get_requests, get_users} from '../backend/accounts.jsx';
//TODO: make the table portion collapsable/ with scroll bar so that it does not render all users at once
//TODO: find a way to pass user specific info to the inpsectSponsor page. Probably has to do with state variables

class AdminViewAdmin extends Component{
    
    constructor(props) {
        super(props);
        this.state = { //state is by default an object
          myAdmins: [
            {userName:"", firstName:"",lastName:""}
          ],
          currentAdmin: "some loser who probably codes late at night"
       }
        this.handleClick = this.handleClick.bind(this);
        this.renderTableData = this.renderTableData.bind(this);
        this.renderTableHeader = this.renderTableHeader.bind(this);
        this.handleInspect = this.handleInspect.bind(this);
        this.handleAdminSelect = this.handleAdminSelect.bind(this);
      }
      handleClick() {
        console.log('Click happened');
        coseole.log(this.props.page);
      }

      handleInspect(event){
        this.props.history.push("/AdminInspectAdmin");
      }

      componentDidMount(){
        // gets sponsors from database 
          get_users('A').then( res => {
          var admins = [];
          console.log(res.data.users[0].username)
          res.data.users.forEach( user => admins.push(
            {
              userName: user.username,
              firstName: user.first_name,
              lastName: user.last_name
            }));
          this.setState({myAdmins:admins});
          //console.log(admins)
          });
          //console.log(this.state.myAdmins)
      }

      renderTableData() {
        //if(drivers)
        return this.state.myAdmins.map((user, index) => {
           const { userName, firstName, lastName } = user //destructuring
           return (
              <tr key={index}>
                 {/* <td>{id}</td> */}
                 <td>
                    <Link 
                      to={this.props.match.url+"/AdminInspectAdmin"}
                      value={userName}
                      onClick={() => this.handleAdminSelect(userName)}>
                      {userName}
                    </Link>
                  </td>
                 <td>{firstName}</td>
                 <td>{lastName}</td>
                 {/* <td>{Change}</td>  */}
              </tr>
           )
        })
      }

      renderTableHeader() {
        let header = Object.keys(this.state.myAdmins[0])
        return header.map((key, index) => {
            return <th key={index}>{key.toUpperCase()}</th>
        })
      }

      handleAdminSelect(value){
        this.setState({currentAdmin: value})
        console.log(this.state.currentAdmin)
      }
        
      render() {
        return(
            <div className='DriverList'>
              <header>
                <h1 className='title'>Admins</h1>   
                  <table className='drivers'>
                    <tbody className='table'>
                      <tr>{this.renderTableHeader()}</tr>
                      {this.renderTableData()}
                    </tbody>
                  </table>
              </header>
              <Switch>
              <Route 
                  path={this.props.match.url+"/AdminInspectAdmin"} 
                  render={() =><AdminInspectAdmin passDownUserName = {this.state.currentAdmin} />}>
                </Route>
              </Switch>
            </div>
        ) 
      }
}
export default withRouter(AdminViewAdmin);