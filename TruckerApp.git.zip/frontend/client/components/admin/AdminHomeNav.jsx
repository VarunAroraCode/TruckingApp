
import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown } from 'react-bootstrap';
import { Route, Switch, Link, withRouter} from 'react-router-dom';
import {logout} from '../backend/auth.jsx';
import AdminViewSponsors from './AdminViewSponsors.jsx';
import AdminViewDrivers from './AdminViewDrivers.jsx';
import './Admin.css';
import {get_requests, get_users} from '../backend/accounts.jsx';
//TODO: make the "View as..." links go to driverHome.jsx and sponsorHome.jsx with template data


class AdminHomeNav extends Component{
    
    constructor(props) {
        super(props);
        this.handleClick = this.handleClick.bind(this);
      }

      handleClick() {
	      logout();
	      this.props.history.push('/');
      }

      render() {
        return(
	    <div>
        <Navbar collapseOnSelect expand="lg" bg="light"  >
            <Navbar.Collapse>
            <Navbar.Brand>
            <Nav.Link as={Link} to={this.props.match.url}>Trucking Rewards</Nav.Link>
            </Navbar.Brand>
            <Nav className="container-fluid">
            <Nav.Link as={Link} to={this.props.match.url}>Home</Nav.Link>
            <Nav.Link as={Link} to={this.props.match.url+"/AdminViewSponsors"}>Sponsors</Nav.Link>
            <Nav.Link as={Link} to={this.props.match.url+"/AdminViewDrivers"}>Drivers</Nav.Link>
            <Nav.Link as={Link} to={this.props.match.url+"/AdminViewAdmin"}>Admins</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/AdminSettings"}>Settings</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/AdminRegister"}>Create User</Nav.Link>
			<Nav.Link as={Link} to={this.props.match.url+"/AdminReports"}>Reports</Nav.Link>
            <NavDropdown title="View as..." id="nav-dropdown">
				{/* TODO match.url+ here*/}
				<NavDropdown.Item as={Link} to={"/ViewAsSponsorHome"}>Sponsor</NavDropdown.Item>
				<NavDropdown.Item as={Link} to={"/ViewAsDriverHome"}>Driver</NavDropdown.Item>
			</NavDropdown>
            <Nav.Item className="ml-auto">
                <Button onClick={this.handleClick}>Logout</Button>
            </Nav.Item>
            </Nav>
            </Navbar.Collapse>
        </Navbar>
	    </div>	
        ) 
      }
}
export default withRouter(AdminHomeNav);
