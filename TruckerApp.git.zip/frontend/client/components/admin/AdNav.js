import React from 'react';
import { Link } from 'react-router-dom';
//BUTTON WILL NEED SOMETHING LIKE onClick={this.props.page}>Logout IN ORDER TO LOGOUT

function AdNav() {
    return (
        <nav>
            <ul className="nav-links">
                <li>Home</li>
                <li>Sponsors</li>
                <li>Drivers</li>
                <li>Reports</li>
                <li><button>Logout</button></li>
            </ul>
        </nav>
    )
}