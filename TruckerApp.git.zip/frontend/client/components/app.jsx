import React from 'react';
import axios from 'axios';
import './app.css';
import DriverHome from './driver/DriverHome.jsx';
import ViewAsDriverHome from './driver/ViewAsDriverHome.jsx';
import SponsorHome from './sponsor/SponsorHome.jsx';
import ViewAsSponsorHome from './sponsor/ViewAsSponsorHome.jsx';
import AdminHome from './admin/AdminHome.jsx';
import Login from './Login.jsx';
import Register from './Register.jsx';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
    HashRouter,
    Switch,
    Route
} from "react-router-dom";


class App extends React.Component {

    // App holds global state, things that will be needed in all pages
    constructor(props) {
	super(props);
        this.state = {
            userData : {
                userType: "",
                username: "",
                points: 0
            },
            auth: false
        };
        this.setAuth = this.setAuth.bind(this);
        this.setUserData = this.setUserData.bind(this);
    }

    //this is going to check the values for any REST api requests
    //most likely going to be a post request sending the data for the username and password
    //then checking if that matches with the database information, and if it does, login occurs.
    componentDidMount() {
    }

    // --- START OF PASS UP FUNCTIONS ---
    // These functions are for to be passed down to components
    // they use these functions to change global state
    
    setAuth(value){
        this.setState({
            auth: value
        })
    }
    setUserData(value){
        this.setState({
            userData: value
        })
    }

    // This should only contain routes to pages
    // Additioanlly you can wrap in a div and render other global components
    // You could do like a Navbar here or a button that should always be visible
    render() {
	return (
	    <HashRouter>
		<Switch>
            
		    <Route exact path="/">
			<Login passupAuth={this.setAuth} passupUserData={this.setUserData} />	
		    </Route>
            
            {/* TODO add navbar beneath the route here and take out navbar from register */}
            <Route path="/Register">
			<Register/>	
		    </Route> 

		    <Route path="/DriverHome">
			<DriverHome passdownUsername={this.state.userData.username} passdownPoints={this.state.userData.points} />
		    </Route>

            <Route path="/ViewAsDriverHome">
			<ViewAsDriverHome passdownUsername={this.state.userData.username} passdownPoints={this.state.userData.points} />
		    </Route>

		    <Route path="/SponsorHome">
			<SponsorHome passdownUsername = {this.state.userData.username} />
		    </Route>

            <Route path="/ViewAsSponsorHome">
			<ViewAsSponsorHome passdownUsername = {this.state.userData.username} />
		    </Route>

		    <Route path="/AdminHome" >
			<AdminHome passdownUsername={this.state.userData.username}/>
		    </Route>

		</Switch>
	    </HashRouter>
	);
    }
}
export default App
