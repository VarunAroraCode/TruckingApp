import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import {get_users, send_request} from '../backend/accounts.jsx';
import {driver_info} from '../backend/driver.jsx';
import {sponsor_info,change_rate} from '../backend/accounts.jsx';


class SponsorHomePage extends Component{
    
  constructor(props) {
      super(props);
      this.state = {
        rate:null,
        newRate:null 
      }
      this.handleClick = this.handleClick.bind(this);
      this.handleOnChange =this.handleOnChange.bind(this);
      //this.renderTableData = this.renderTableData.bind(this)
    }
    handleClick() {
      console.log("hi");
      logout();
      this.props.history.push("/");
    }
    handleOnChange(){
        if(this.state.newRate == null){
            alert("Please Enter a Number");
        }
        else{
        change_rate(this.state.newRate);
        window.location.reload(false);
        }
    }

       componentDidMount(){
        sponsor_info().then( res => {
            console.log(res.data.points_to_cents);
            this.setState({rate: res.data.points_to_cents});
            console.log(this.state.rate);
            
                });
        }  
       
    
/*
   renderTableData() {
   return this.state.sponsorList.map((data, index) => {
   const { points, sponsor } = data //destructuring
   return (
   <tr key={sponsor}>
   <td>
   Sponsor Name: {sponsor} <br/> 
   Available Points: {points} <br/>
   -------------------------- <br/> <br/>
       </td>
      </tr>
    )
   })
  }
  */
	                                                                                                                        
	    

  render() {
      return(
        <div>

          <h1>Welcome   {this.props.sponsorUsername}!</h1> <br/><br/><br/>

          <h3>Your Current Points to Cents Conversion Rate: {this.state.rate} Point(s) to 1 Cent</h3><br/><br/>
          <Form>
			<Form.Group controlId="formRate">
			<Form.Control type = "number" placeholder = "Enter a New Point Conversion Rate (Single Number)"
			onChange={(event,newValue) => this.setState({newRate:event.target.value})}
			/>
			</Form.Group>
			<br/>
            <Button label = "Submit" onClick={(event) => this.handleOnChange(event)}> Submit Changes </Button>
            </Form>
          
        </div>
      )
  }
}
export default withRouter(SponsorHomePage);
