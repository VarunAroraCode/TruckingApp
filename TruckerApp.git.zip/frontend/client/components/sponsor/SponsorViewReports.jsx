import React, { Component } from 'react';
import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import {Container, Navbar, Nav, DropdownButton, Form, Button} from 'react-bootstrap';
import {alterDriver} from '../backend/driver.jsx';
import {change_points, sponsor_all_reports, get_drivers} from '../backend/accounts.jsx';
import './Sponsor.css'


class SponsorViewReports extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
            reports:[{point_change:null,reason:'',driver:{},sponsor:{},created_at:'',}],
            drivers:[{username:''}],
            selectedDriver:'',
            start:'',
            end:''
        
        }
        this.handleClick = this.handleClick.bind(this);
        this.get_reports=this.get_reports.bind(this);
        this.clear=this.clear.bind(this);
        this.checkName=this.checkName.bind(this);
      }
      handleClick() {
          logout();
	      this.props.history.push("/");
      }

      componentDidMount(){
        get_drivers().then(res=>{
                console.log(res.data.points);
              var results = [];
              res.data.points.forEach(point=>results.push({
                 username:point.driver
              }));
              this.setState({drivers:results})
              console.log(this.state.drivers);
                
             // console.log(res)
            })
      }

      get_reports(username,start,end){
        console.log(this.state.start)
        console.log(this.state.end)
        console.log(this.state.selectedDriver);

        sponsor_all_reports(username,start,end).then(res=>{
        console.log(this.state.reports[0].reason);
        
          var results = [];
          res.data.changes.forEach(change=>results.push({
              point_change:change.point_change,
              reason:change.reason,
              driver:change.driver,
              sponsor:change.sponsor,
              created_at:change.created_at
          }));
          this.setState({reports:results})
          console.log(this.state.reports);
          console.log(this.state.reports.length);
            
         // console.log(res)
        })
      }
      clear(){
        window.location.reload(false);
      }

      checkName(){
          console.log(this.state.selectedDriver)
      }
      
      renderTableData() {
        //if(drivers)
        return this.state.reports.map((reports, index) => {
            const { point_change,reason,driver,sponsor,created_at,} = reports //destructuring
            //console.log(driver)
            return (
              <tr key={point_change}>
                  <td>{point_change}</td>
                  <td>{reason}</td>
                  <td>{driver.username}</td>
                  <td>{sponsor.username}</td>
                  <td>{created_at}</td>
                  
                  
              </tr>
              
            )
            
        })
      }


      handleOnSubmit(event){

      }


      render() {
        if(this.state.reports[0] == null){
            return(
            <div>
                <h1>No Reports</h1>
                <Button onClick={()=>{this.clear()}}>Clear</Button>
            </div>
            )
        }

       else if(this.state.reports[0].reason == '' ){
            return(
                <div>
                    
                    <Button onClick={()=>{this.get_reports("","","")}}>View All Reports</Button>
                    <br/>
                    <br/>
                    Or
                    <br/>
                    <br/>
                    Select a Driver (Optional): 
                    <br/>
                    <br/>
                    
                    <select value = {this.state.selectedDriver}
                    onChange={e => this.setState({selectedDriver:e.target.value})}>
                        <option value="">Select a Driver</option>
                        {this.state.drivers.map((driver)=> <option key = {driver.username} value = {driver.username}>{driver.username}</option>)}
                    </select>
                    <br/>
                    <br/>
                    {/*<Button onClick={()=>{this.get_reports(this.state.selectedDriver,"","")}}>View Driver's Reports</Button>*/}
                    <br/>
                    <br/>
                    Select a Date Range: (Optional)
                    <Form>
			            <Form.Group controlId="formDateStart">
			                <Form.Control type = "text" placeholder = "Enter Start Date (dd/mm/yyyy)"
			                onChange={(event,newValue) => this.setState({start:event.target.value})}
			            />
			                </Form.Group>
                            <Form.Group controlId="formDateEnd">
			                <Form.Control type = "text" placeholder = "Enter End Date (dd/mm/yyyy)"
			                onChange={(event,newValue) => this.setState({end:event.target.value})}
			            />
			                </Form.Group>
                    </Form>
                    <Button onClick={()=>{this.get_reports(this.state.selectedDriver,this.state.start, this.state.end)}}>View Driver's Reports</Button>
                    
                </div>
            )
        }
        else{
        return(
          <div>
            <h1>heyo</h1>
            <Button onClick={()=>{this.clear()}}>Clear</Button>
            <br/>
            <br/>
            <table className="spaceTable">
            <thead>
	                <tr>
	                  <th>Point Change</th>
	                  <th>Reason</th>
                      <th>Driver</th>
                      <th>Sponsor</th>
                    <th>Date </th>
	                </tr>
	              </thead> 
                
                   <tbody>
                       {/*<tr>{this.renderTableHeader()}</tr>*/}
                      {this.renderTableData()}
                   </tbody>
                </table>
          </div>
             
        ) 
        }
      }
}
export default withRouter(SponsorViewReports);

