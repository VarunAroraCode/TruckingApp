import React, { Component } from 'react';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, Link } from 'react-router-dom';
import './Sponsor.css';
import {change_points, sponsor_all_reports} from '../backend/accounts.jsx';
import {respond_request, get_requests, get_users} from '../backend/accounts.jsx';
class ViewAsDriverPoints extends Component{
	    
	    constructor(props) {
		            super(props);
		    	    this.state={
				    points:null,
				    reason:'',
					check:''
			    };
		    	    this.handleOnChange=this.handleOnChange.bind(this);
		            this.handleClick = this.handleClick.bind(this);
					this.handleRemove=this.handleRemove.bind(this);
		          }
	      handleClick() {
		              console.log('Click happened');
		              coseole.log(this.props.page);
		            }
	      handleOnChange(event){
			  event.preventDefault();
		      console.log(this.state.points);
		      console.log(this.state.reason);
		      change_points(this.props.passDownDriver, this.state.points, this.state.reason);
			  window.location.reload(false);
	      }
		  handleRemove(event){
			  if (this.state.check == "Remove"){
				respond_request(this.props.passDownDriver, false)
				window.location.reload(false);
			  }
			  else{
				  alert("Please type Remove in Form to Remove Driver: " + this.props.passDownDriver)
			  }
		  }
	render(){
		return(
			<BrowserRouter>
			<div>
			<h2>Add or Remove Points from Driver: {this.props.passDownDriver}</h2>
	
			

			<Form>
			<Form.Group controlId="formPoints">
			<Form.Control type = "number" placeholder = "Enter the Amount of Points(+/-)"
			onChange={(event,newValue) => this.setState({points:event.target.value})}
			/>
			</Form.Group>
			<br/>
			<Form.Group controlId="formReason">
			<Form.Control type ="text" placeholder = "Please Enter a Reason for Point Changes"
			onChange={(event,newValue) => this.setState({reason:event.target.value})}
			/>
			</Form.Group>
			<br/>
			<Button label = "Submit" onClick={(event) => this.handleOnChange(event)}> Submit Changes </Button>
			</Form>
			
			<br/>
			<br/>

			<h2>Or Remove the Driver from Your Sponsorship</h2>
			
				<Form>
					<Form.Group controlId = "formRemove">
						<Form.Control type = "text" placeholder = "Please Type 'Remove' and then Press the Button to Remove this Driver"
						onChange={(event,newValue) => this.setState({check:event.target.value})}
						/>
					</Form.Group>
	
					<Button label = "Submit" onClick={(event) => this.handleRemove(event)}>Remove</Button>
				</Form>
			
			</div>
			</BrowserRouter>
			
		)}
}
export default ViewAsDriverPoints
