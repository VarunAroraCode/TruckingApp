import React, { Component } from 'react';
//import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './Sponsor.css'
import {ebay_search, add_to_shop} from '../backend/ebay.jsx';
import {sponsor_info} from '../backend/accounts.jsx';
import './AddToCatalog.css'

class AddToCatalog extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
            rate:null,
            search:'',
            data: [
                //{productName:'',productCost: null, productReviews: null, image: ''} 
                {image: '', productName:'', productCost:null, productReviews:null}               
            ],
            checked: false,
           
            



        }
        this.handleClick = this.handleClick.bind(this);
        this.renderTableData = this.renderTableData.bind(this);
        this.onSearch=this.onSearch.bind(this);
        this.testing=this.testing.bind(this);
        this.addItem=this.addItem.bind(this);

      }
      handleClick() {
          logout();
	  this.props.history.push("/");
      }
      /*
      onClick(){
          this.setState({show: true});
      }
      */

      componentDidMount(){
        sponsor_info().then( res => {
            console.log(res.data.points_to_cents);
            this.setState({rate: res.data.points_to_cents});
            console.log(this.state.rate);
            
                });
        }  


      /*

      
      
      componentDidMount() {
          ebay_search('watch').then(res=>{
            var results = [];
            res.data.items.forEach(item=>results.push({
                
                image: item.image,
                productName: item.productName,
                productCost: item.productCost,
                productReviews: item.productReviews,
                
            }));
           // this.setState({test:res.data.items});
           // console.log(this.state.test);
           console.log(results)
           this.setState({data:results});
           console.log(this.data)
          });
      }
      */
     
      onSearch(event){
        
          console.log(this.state.search)
          ebay_search(this.state.search).then(res=>{
            var results = [];
            res.data.items.forEach(item=>results.push({
                
                image: item.image,
                productName: item.productName,
                productCost: Math.round(item.productCost * 100 * this.state.rate),
                productReviews: item.productReviews,
                
            }));
           // this.setState({test:res.data.items});
           // console.log(this.state.test);
           console.log(results)
           this.setState({data:results});
           console.log(this.data)
          });
          //window.location.reload(false);
      }

      addItem(productName, productCost, productReviews, image){
          //console.log('this was called')
          
          add_to_shop(productName,productCost,productReviews,image);
          //window.location.reload(false);

      }
      
          
          
          
        
    

      /* This function will call the POST request with the information returned from the GET (search) 
      function. ????*/
    // AddItem(){
    //   console.log("added item to catalog")
    //   event.preventDefault();
    
    // }
    
    /*This function will remove an item from the displayed catalog/db table*/
    //RemoveItem(){

    //}

    renderTableData() {
      //if(drivers)
      return this.state.data.map((data, index) => {
          const { productName, productCost, productReviews, image } = data //destructuring

          return (
            <tr key={productName}>
                <td className = "catalogCenter"><img src = {image} height = "100"/></td>
                <td>{productName}</td>
                <td>{productCost} </td>
                <td>{productReviews}</td>
                <Button onClick={()=>{this.addItem(productName,productCost,productReviews,image)}}>Add</Button>
            </tr>
            
          )
          
      })
    }

    testing(event){
        console.log(this.state.search)
    }
    renderTableHeader() {
      let header = Object.keys(this.state.data[0])
      return header.map((key, index) => {
         return <th key={index}>{key.toUpperCase()}</th>
      })
      /*
      return <tr>
          <th>Image</th>
          <th>Name</th>
          <th>Cost</th>
          <th>Reviews</th>  
          
      </tr>
      */
   }

   /*this will call the GET (ebay search function) to set the states of the variables listed in the 
   constructor. it will also set show to true which will re render and display the product
   that was searched for*/

   
      render(){
          console.log(this.search)
        return(
          <div >
            <header>
              <h1>Select an Item to Add to Your Catalog</h1>  
              <Form>
              <Form.Group controlId="formSearch">
		    <Form.Control type="text" placeholder="Search For a Product to Add"
			onChange = {(event,newValue) => this.setState({search:event.target.value})}
            
		    />
            
            
            

	    	</Form.Group>
        
            <Button label="Submit" onClick={(event) => this.onSearch(event)}>
		Search
		</Button>

           
        </Form>

        
            <br/>
              </header> 
              
              {/*After the search is finished, the product will be displayed where these breaks are
              with an option to Add next to it. */}
             
              <table className ="spaceTable">

              <thead>
	            <tr>
	                <th>Image</th>
	                <th>Name</th>
                    <th>Cost (Points)</th>
                    <th>Reviews</th>
                    <th> </th>
	            </tr>
	         </thead>                  
                   <tbody>
                       {/*<tr>{this.renderTableHeader()}</tr>*/}
                      {this.renderTableData()}
                   </tbody>
                </table>
            
          </div>
        ) 
      }
}
export default withRouter(AddToCatalog);