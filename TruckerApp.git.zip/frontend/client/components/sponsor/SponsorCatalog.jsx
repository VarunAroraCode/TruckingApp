import React, { Component } from 'react';
//import Image from 'react-random-image'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl, Table } from 'react-bootstrap';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';import {logout} from '../backend/auth.jsx';
import {withRouter} from 'react-router-dom';
import './Sponsor.css'
import {ebay_search,get_catalog,remove_from_shop} from '../backend/ebay.jsx';

class SponsorCatalog extends Component{
    
    constructor(props) {
        super(props);
        this.state = {
            data: [
                {image:'',productName: '', productCost: null, productReviews: null}
                
            ],


        }
        this.handleClick = this.handleClick.bind(this);
        this.renderTableData = this.renderTableData.bind(this);
        //this.showProduct=this.showProduct.bind(this);
        //this.onClick=this.onClick.bind(this);
        //this.onClear=this.onClear.bind(this);
        this.removeItem=this.removeItem.bind(this);
      }
      handleClick() {
          logout();
	  this.props.history.push("/");
      }
     

      componentDidMount() {
          get_catalog().then(res=>{
            var results = [];
            res.data.items.forEach(item=>results.push({
                
                image: item.image,
                productName: item.productName,
                productCost: item.productCost,
                productReviews: item.productReviews,
                
            }));
           // this.setState({test:res.data.items});
           // console.log(this.state.test);
           console.log(results)
           this.setState({data:results});
           console.log(this.data)
          });
      }

      removeItem(productName, productCost, productReviews, image){
        //console.log('this was called')
        
        remove_from_shop(productName,productCost,productReviews,image);
        window.location.reload(false);

    }
          
          
          
        
    

      /* This function will call the POST request with the information returned from the GET (search) 
      function. ????*/
    // AddItem(){
    //   console.log("added item to catalog")
    //   event.preventDefault();
    
    // }
    
    /*This function will remove an item from the displayed catalog/db table*/
    //RemoveItem(){

    //}

    renderTableData() {
      //if(drivers)
      return this.state.data.map((data, index) => {
          const { image,productName, productCost, productReviews} = data //destructuring
          return (
            <tr key={productName}>
                <td className = "catalogCenter"><img src = {image} height = "100"/></td>
                <td>{productName}</td>
                <td>{productCost}</td>
                <td>{productReviews}</td>
                
                <Button onClick={()=>{this.removeItem(productName,productCost,productReviews,image)}}>Remove</Button>
            </tr>
            
          )
          
      })
    }

    
    renderTableHeader() {
      let header = Object.keys(this.state.data[0])
      return header.map((key, index) => {
         return <th key={index}>{key.toUpperCase()}</th>
      })
   }

   /*this will call the GET (ebay search function) to set the states of the variables listed in the 
   constructor. it will also set show to true which will re render and display the product
   that was searched for*/

   showProduct(event) {
    console.log("this thing has been pressed")
    console.log(this.state.product_search)
    
    //this.state.show=true;
    console.log(this.state.show)


    /*a temporary return for testing when the search button displays data, will eventually be replaced
    with a way to display the items returned from GET*/

    return this.renderTableHeader()
    
    
    }
      render(){
        if(this.state.data.length > 0){
        return(
          <div >
            <header>
              <h1>Current Catalog available for purchase:</h1>  
              

        
            <br/>
              </header> 
              
              {/*After the search is finished, the product will be displayed where these breaks are
              with an option to Add next to it. */}
              <table className ="spaceTable">

                <thead>
	                <tr>
	                  <th>Image</th>
	                  <th>Name</th>
                    <th>Cost (Points)</th>
                    <th>Reviews</th>
                    <th> </th>
	                </tr>
	              </thead> 
                
                   <tbody>
                       {/*<tr>{this.renderTableHeader()}</tr>*/}
                      {this.renderTableData()}
                   </tbody>
                </table>
            
          </div>
        ) 
            }
      else{
        return(<div>
          <h1>There are currently no items in your catalog!</h1>
        </div>)
      }
      }
}
export default withRouter(SponsorCatalog);