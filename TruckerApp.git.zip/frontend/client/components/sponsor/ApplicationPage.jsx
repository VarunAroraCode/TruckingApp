import React, {Component} from 'react';
//import axios from 'axios';
import './SponsorHome.css';
import './Sponsor.css';
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Brand, Form, FormControl } from 'react-bootstrap';
import { BrowserRouter, Route, Switch, withRouter } from 'react-router-dom';
//import Navbar from 'react-bootstrap/Navbar'
//import DriverHome from './driver/DriverHome.jsx'
//import DriverList from './DriverList';
import {respond_request, get_requests, get_users} from '../backend/accounts.jsx';

class ApplicationPage extends Component {

  constructor(props) {
    super(props);
    this.state = {
	    requests : [{username:"", user_type:"", first_name:"", last_name:""}]   
    }
  }


  componentDidMount() {

      get_requests().then(res => { 
	      var reqs = [];
	      res.data.requests
		      .filter( req => req.status === null)
	      	      .forEach( req => reqs.push( req.driver.account ) );
	      if(reqs.length > 0){
		this.setState({requests: reqs});
		console.log(this.state.requests);
	      }
      })
        
        
        
      
  }

  renderTableHeader() {
    let header = Object.keys(this.state.requests[0])
    return header.map((key, index) => {
       return <th key={index}>{key.toUpperCase()}</th>
    })
 }

 renderTableData() {
  //if(requests.users){
  return this.state.requests.map((request, index) => {
     const { username, user_type,first_name,last_name } = request //destructuring
     return (
        <tr key={username}>
           <td>{username}</td>
           <td>{user_type}</td>
           <td>{first_name}</td>
           <td>{last_name}</td>
           <td><Button value={true} onClick={e => respond_request(username, e.target.value) } >Accept</Button></td>
           <td><Button value={false} onClick={e => respond_request(username, e.target.value) } >Deny</Button></td>
        </tr>
     )
     
  })
//}
  
}

  
  
 
  handleClick() {

   // history.push("/")
    console.log('Click happened');
    console.log(this.props.page)

  }


  render() {
  
    if (this.state.requests==null) return null;
    
    //console.log(this.state.requests.users);
    //console.log(this.state.requests.users[1]);
    if (this.state.requests!=null){
    //console.log(this.state.requests.users[3].first_name);
    return(
      
        <div>
          
          <h1>
            WOOOOO
          </h1>
          
          <table className='drivers'>
               <tbody>
                   <tr>{this.renderTableHeader()}</tr>
                   {this.renderTableData()}
                   </tbody>
                   </table>
          
          
               
          
        </div>
    ) 
        }
  }
}
export default ApplicationPage

