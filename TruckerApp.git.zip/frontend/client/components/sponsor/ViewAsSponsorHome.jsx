import React, {Component} from 'react';
import DriverList from './DriverList.jsx';
import ViewAsSponsorCatalog from './ViewAsSponsorCatalog.jsx';
import SponsorHomeNav from './SponsorHomeNav.jsx';
import ViewAsApplicationPage from './ViewAsApplicationPage.jsx';
import ViewAsAddToCatalog from './ViewAsAddToCatalog.jsx';
import SponsorHomePage from './SponsorHomePage.jsx';
import ViewAsSponsorSettings from './ViewAsSponsorSettings.jsx';
import ViewAsSponsorViewReports from './ViewAsSponsorViewReports.jsx'
import ViewAsSponsorHomeNav from './ViewAsSponsorHomeNav.jsx';
import ViewAsSponsorHomePage from './ViewAsSponsorHomePage.jsx';
import ViewAsDriverList from './ViewAsDriverList.jsx';
import './Sponsor.css';
import{
  Link,
  Switch,
  Route,
  withRouter
} from 'react-router-dom';
import {get_requests, get_users} from '../backend/accounts.jsx';
//import DriverList from './DriverList';



class ViewAsSponsorHome extends Component {
  constructor(props) {
    
    super(props);

    this.state ={
      username: this.props.passdownUsername
    }

    this.handleClick = this.handleClick.bind(this);
  }

  componentDidMount() {
    console.log(this.props.passdownUsername);
    get_requests(true).then(res => {
	    console.log(res);
    });
    get_users('S').then( res =>{ console.log(res);} );
  }
 
  handleClick() {
   // history.push("/")
    console.log('Click happened');
  }


  render() {
    return(
      <div>
        
        <ViewAsSponsorHomeNav>
        </ViewAsSponsorHomeNav>
        <Switch>
        <Route exact path={this.props.match.path}> <ViewAsSponsorHomePage sponsorUsername={this.state.username}/></Route>
          <Route path={this.props.match.path+"/ViewAsDriverList"}><ViewAsDriverList/></Route>
          <Route path={this.props.match.url+"/ViewAsApplicationPage"}><ViewAsApplicationPage/></Route>
          <Route path={this.props.match.path+"/ViewAsSponsorCatalog"}><ViewAsSponsorCatalog/></Route>
          <Route path={this.props.match.path+"/ViewAsAddToCatalog"}><ViewAsAddToCatalog/></Route>
          <Route path={this.props.match.path+"/ViewAsSponsorSettings"} > <ViewAsSponsorSettings />  </Route>
          <Route path={this.props.match.path+"/ViewAsSponsorViewReports"} > <ViewAsSponsorViewReports />  </Route>
          
        </Switch>
      </div>

    )
  }
}
export default withRouter(ViewAsSponsorHome);
