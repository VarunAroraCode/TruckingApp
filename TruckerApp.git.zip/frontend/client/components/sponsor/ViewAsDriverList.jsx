import React, {Component} from 'react';
//import axios from 'axios';
import './DriverList.css';
//import Navbar from 'react-bootstrap/Navbar'
import { Button, Navbar, Nav, NavItem, NavDropdown, MenuItem, Form, NavbarBrand, Brand, FormControl} from 'react-bootstrap';
//import DriverHome from './driver/DriverHome.jsx'
import {respond_request, get_requests, get_users, get_drivers} from '../backend/accounts.jsx';
import ViewAsDriverPoints from './DriverPoints.jsx';
import { BrowserRouter, Route, Switch, Link, withRouter } from 'react-router-dom';
class ViewAsDriverList extends Component {
    constructor(props) {
        super(props) //since we are extending class Table so we have to use super in order to override Component class constructor
        this.state = { //state is by default an object
		requests : [{driver:' ', points: null}],
		currentDriver: 'Please Select a Driver From Your List',
        }
	this.handleDriverSelect = this.handleDriverSelect.bind(this);
	this.handleClick = this.handleClick.bind(this);
	this.handleDriverSelect = this.handleDriverSelect.bind(this);
	this.handleInspect=this.handleInspect.bind(this);
    }
     componentDidMount() {

	     get_drivers().then(res => { 
	      var reqs = [];
	      console.log(res);
	      res.data.points.forEach(point => reqs.push(
		   	{
				driver:point.driver,
				points:point.points
			}
	      ));
	      if(reqs.length > 0){
		this.setState({requests: reqs});
		console.log(this.state.requests);
	      }
      })
        
        
        
      
  }

handleDriverSelect(value){
	        this.setState({currentDriver: value})
	        console.log(this.state.currentDriver)
}

handleInspect(event){
	this.props.hisory.push("/DriverPoints");
}

  handleClick() {
    console.log('Click happened');
    console.log(this.props.page)
  }
  renderTableData() {
    //if(drivers)
    return this.state.requests.map((data, index) => {
       const { driver, points} = data //destructuring
       return (
          <tr key={driver}>
             <td>
	       <Link
	       to={this.props.match.url+"/DriverPoints"}
	       value={driver}
	       onClick={() => this.handleDriverSelect(driver)}>
	       {driver}
	       </Link>
	       </td>
             <td>{points}</td>
	       
	  </tr>
          
       )
       
    })
    
 }

 renderTableHeader() {
    let header = Object.keys(this.state.requests[0])
    return header.map((key, index) => {
       return <th key={index}>{key.toUpperCase()}</th>
    }
    )
	 
 }

 
  render() {
   
    return(
	    
	<div className='DriverList'>
      <h1>Your Current Drivers:</h1>
      <br></br>
      <h5>Select a Name and Scroll Down to Edit Points or Remove the Driver</h5>
        <header className ='background'>
          <h1 className='title'>Current Drivers</h1>   
          <table className='drivers'>
	    <thead>
	    <tr>
	    <th>Driver</th>
	    <th>Points</th>
	    
	    </tr>
	    </thead>
               <tbody>
	    {/*       <tr>{this.renderTableHeader()}</tr>*/}
                  {this.renderTableData()}
               </tbody>
            </table>
        </header>
	<Switch>
	 <Route 
	    path={this.props.match.url+"/DriverPoints"}
	    render={() => <ViewAsDriverPoints passDownDriver ={this.state.currentDriver}/>}>
	    </Route>
	    </Switch>
          
        

      </div>
        
    ) 
  }
}

  
export default withRouter(ViewAsDriverList);
