import React, {Component} from 'react';
import { NavItem, Nav, Navbar, Button, NavDropdown} from 'react-bootstrap';
import {Route, Swtich, Link, withRouter} from 'react-router-dom';
import {logout} from '../backend/auth.jsx';
import './Sponsor.css'
import {get_drivers} from '../backend/accounts.jsx';

class SponsorHomeNav extends Component{
    

    constructor(props){
        super(props);
        this.state={
            requests : [{driver:' ', points: null}],
            driver:""
        }
        this.handleClick=this.handleClick.bind(this);
    }
    componentDidMount() {

        get_drivers().then(res => { 
         var reqs = [];
         console.log(res);
         res.data.points.forEach(point => reqs.push(
              {
               driver:point.driver,
               points:point.points
           }
         ));
         if(reqs.length > 0){
       this.setState({requests: reqs});
       console.log(this.state.requests);
         }
     })
    }

    handleClick(){
        logout();
        this.props.history.push('/');
    }
    render(){
        return(
            <div>
                <Navbar collapseOnSelect expand ="lg" bg="light">
                    <Navbar.Collapse> 
                    <Navbar.Brand>
                        <Nav.Link as={Link} to={this.props.match.url}>Trucking Rewards</Nav.Link>
                    </Navbar.Brand>
                    <Nav className="container-fluid">
                        <Nav.Link as={Link} to={this.props.match.url}>Home</Nav.Link>
                        <Nav.Link as={Link} to={this.props.match.url+"/DriverList"}>Drivers</Nav.Link>
                        <Nav.Link as={Link} to={this.props.match.url+"/ApplicationPage"}>Applications</Nav.Link>
                        <Nav.Link as={Link} to={this.props.match.url+"/SponsorCatalog"}>Catalog</Nav.Link>
                        <Nav.Link as={Link} to={this.props.match.url+"/AddToCatalog"}>Add To Catalog</Nav.Link>
                        <Nav.Link as={Link} to={this.props.match.url+"/SponsorSettings"}>Settings</Nav.Link>
                        <Nav.Link as={Link} to={this.props.match.url+"/SponsorViewReports"}>View Reports</Nav.Link>
                        <Nav.Link as={Link} to={"/ViewAsDriverHome"}>View As a Driver</Nav.Link>
                        {/*<select value = {this.state.selectedDriver}
                    onChange={e => this.setState({selectedDriver:e.target.value})}>
                        <option value="">Select a Driver</option>
                        {this.state.drivers.map((driver)=> <option key = {driver.username} value = {driver.username}>{driver.username}</option>)}
                    </select>
                    */}
                        <NavDropdown title="View as..." id="nav-dropdown">

				{/* TODO match.url+ here*/}
                {this.state.requests.map((request)=> <NavDropdown.Item as={Link} to ={{ pathname:"/ViewAsDriverHome", state:{passDownUsername:request.driver} }}>{request.driver}</NavDropdown.Item>)}
				
			</NavDropdown>
                        <Nav.Item className="ml-auto">
                            <Button onClick={this.handleClick}>Logout</Button>
                        </Nav.Item>

                    </Nav>

                    </Navbar.Collapse>
                </Navbar>,
            </div>
        )
    }
}
export default withRouter(SponsorHomeNav);