import React, {Component} from 'react';
import DriverList from './DriverList.jsx';
import SponsorCatalog from './SponsorCatalog.jsx';
import SponsorHomeNav from './SponsorHomeNav.jsx';
import ApplicationPage from './ApplicationPage.jsx';
import AddToCatalog from './AddToCatalog.jsx';
import SponsorHomePage from './SponsorHomePage.jsx';
import SponsorSettings from './SponsorSettings.jsx';
import SponsorViewReports from './SponsorViewReports.jsx'
import ViewAsSponsorHome from './ViewAsSponsorHome.jsx';
import ViewAsDriverHome from '../driver/ViewAsDriverHome.jsx';
import './Sponsor.css';
import{
  Link,
  Switch,
  Route,
  withRouter
} from 'react-router-dom';
import {get_requests, get_users} from '../backend/accounts.jsx';
//import DriverList from './DriverList';



class SponsorHome extends Component {
  constructor(props) {
    
    super(props);

    this.state ={
      username: this.props.passdownUsername
    }

    this.handleClick = this.handleClick.bind(this);
  }

  componentDidMount() {
    console.log(this.props.passdownUsername);
    get_requests(true).then(res => {
	    console.log(res);
    });
    get_users('S').then( res =>{ console.log(res);} );
  }
 
  handleClick() {
   // history.push("/")
    console.log('Click happened');
  }


  render() {
    return(
      <div>
        
        <SponsorHomeNav>
        </SponsorHomeNav>
        <Switch>
          <Route exact path={this.props.match.path}> <SponsorHomePage sponsorUsername={this.state.username}/></Route>
          <Route path={this.props.match.path+"/DriverList"}><DriverList/></Route>
          <Route path={this.props.match.url+"/ApplicationPage"}><ApplicationPage/></Route>
          <Route path={this.props.match.path+"/SponsorCatalog"}><SponsorCatalog/></Route>
          <Route path={this.props.match.path+"/AddToCatalog"}><AddToCatalog/></Route>
          <Route path={this.props.match.path+"/SponsorSettings"} > <SponsorSettings />  </Route>
          <Route path={this.props.match.path+"/SponsorViewReports"} > <SponsorViewReports />  </Route>
          <Route path={this.props.match.path+"/ViewAsSponsorHome"} > <ViewAsSponsorHome />  </Route>
          <Route path={this.props.match.path+"/ViewAsDriverHome"} > <ViewAsDriverHome passdownUsername={this.props.passdownDriver} />  </Route>
        </Switch>
      </div>

    )
  }
}
export default withRouter(SponsorHome);
