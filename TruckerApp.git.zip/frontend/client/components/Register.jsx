import React, { Component } from 'react';
import axios from 'axios';
import {Container, Navbar, Nav, DropdownButton, Form, Button} from 'react-bootstrap';
// authentication
import { register, set_csrf } from './backend/auth.jsx';
import CSRFToken from './backend/CSRFToken.jsx';
import { Link, withRouter } from 'react-router-dom'
class Register extends Component {
  constructor(props){
    super(props);
    this.state={
      first_name:'',
      last_name:'',
      username: '',
      email:'',
      password:'',
      repassword:'',
      user_type:'D'
    };
    this.handleOnSubmit = this.handleOnSubmit.bind(this);
  }

  componentDidMount(){
	  set_csrf().then( res => {console.log(res);});
  }

  handleOnSubmit(event){
	  register (this.state.username, this.state.email, 
		    this.state.password, this.state.repassword, this.state.user_type, 
		    this.state.first_name, this.state.last_name)
	  .then(res => {
		if("success" in res["data"]){
			alert("account created");
		}else{
			alert("account failed to create");
		}
	  });
  }

  render() {
    return (
	<Container fluid>
	    <Form>
	    	<CSRFToken />
		<Form.Group controlId="formFirstName">
		    <Form.Label>First Name</Form.Label>
		    <Form.Control type="text" placeholder="First Name"
			onChange = {(event,newValue) => this.setState({first_name:event.target.value})}
		    />
	    	</Form.Group>
		<br/>
		<Form.Group controlId="formLastName">
		    <Form.Label>Last Name</Form.Label>
		    <Form.Control type="text" placeholder="Last Name"
			onChange = {(event,newValue) => this.setState({last_name:event.target.value})}
		    />
	    	</Form.Group>
		<br/>
		<Form.Group controlId="formUsername">
		    <Form.Label>Username</Form.Label>
		    <Form.Control type="text" placeholder="Username"
			onChange = {(event,newValue) => this.setState({username:event.target.value})}
		    />
	    	</Form.Group>
		<br/>
		<Form.Group controlId="formEmail">
		    <Form.Label>Email</Form.Label>
		    <Form.Control type="email" placeholder="Email"
			onChange = {(event,newValue) => this.setState({email:event.target.value})}
		    />
	    	</Form.Group>
		<br/>
		<Form.Group controlId="formPassword">
		    <Form.Label>Password</Form.Label>
		    <Form.Control type="password" placeholder="Password"
			onChange = {(event,newValue) => this.setState({password:event.target.value})}
		    />
	    	</Form.Group>
		<br/>
		<Form.Group controlId="formRepassword">
		    <Form.Label>Password Check</Form.Label>
		    <Form.Control type="password" placeholder="Password Check"
			onChange = {(event,newValue) => this.setState({repassword:event.target.value})}
		    />
	    	</Form.Group>
	    	<br/>
		<Form.Group controlId="formUserType">
		    <Form.Label>User Type</Form.Label>
		    <Form.Control as="select"
			custom onChange = {(event,newValue) => this.setState({user_type:event.target.value})}
		    >
			<option value="D" >Driver</option>	
			<option value="A" >Admin</option>	
			<option value="S" >Sponsor</option>	
		    </Form.Control> 
	    	</Form.Group>
		<Button label="Submit" style={style} onClick={(event) => this.handleOnSubmit(event)}>
		Register Account
		</Button>
	    </Form>
	</Container>
    );
  }
}
const style = {
  margin: 15,
};
export default Register;
