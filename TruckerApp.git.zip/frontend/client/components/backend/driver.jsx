import axios from 'axios';
import Cookies from 'js-cookie';
import { get_base_url } from './util.jsx';

var base_url = get_base_url();

const get_header = () => {
	return {
	'Accept':'application/json',
	'Content-Type': 'application/json',
	'X-CSRFToken': Cookies.get('csrftoken')
    };
}

export const driver_info = (username, view_as = "", debug=false) => {
    var headers = get_header();
    var body = {
	'username': username,
	'view_as': view_as
    };

    if(debug == true){
	console.log(username);
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'get',
	    url: base_url + 'driver-info/', 
	    params: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}


export const alterDriver = (username, email, password, re_password,first_name, last_name, debug=false) => {
    var headers = get_header();
    var body = {
	'first_name' : first_name,
	'last_name' : last_name,
	'username':username,
	'password':password,
	're_password':re_password,
	'email':email,
    };
    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url:base_url + 'my-info/', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'alter failed for unknown reason'};
    }

}
export const driver_cart_add = (sponsorusername, productName, image, productCost, productReviews, view_as = "",debug=false) => {
    var headers = get_header();
    var body = {
		"sponsor_username" : sponsorusername,
		"add": [
			 {
				"productName": productName,
				"image": image,
				"productCost": productCost,
				"productReviews": productReviews,
				"view_as": view_as
			}
		]
	}
    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url:base_url + 'ebay/driver-shop', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'alter failed for unknown reason'};
    }
}
export const driver_cart_remove = (sponsorusername, productName, image, productCost, productReviews, view_as = "", debug=false) => {
    var headers = get_header();
    var body = {
		"sponsor_username" : sponsorusername,
		"remove": [
			 {
				"productName": productName,
				"image": image,
				"productCost": productCost,
				"productReviews": productReviews,
				"view_as" : view_as,
			}
		]
	}
    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url:base_url + 'ebay/driver-shop', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'alter failed for unknown reason'};
    }
}


export const driver_cart_buy = (sponsorusername, address, debug=false) => {
    var headers = get_header();
    var body = {
		"sponsor_username" : sponsorusername,
		"address": address
	}
    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url:base_url + 'ebay/buy', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'alter failed for unknown reason'};
    }
}


export const driver_purchase_history = (view_as = "") => {
	var headers= get_header();
	console.log("hello");
	var body = {
		"view_as" : view_as
	}

	try{
		const res = axios({
			method: 'get',
			url:base_url+'purchase-report',
			params: body,
			headers: headers});
		return res;
	}catch{
		return {'error':'request failed to send'};

	}
}

