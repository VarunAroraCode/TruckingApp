import axios from 'axios';
import Cookies from 'js-cookie';
import { get_base_url } from './util.jsx';


var base_url = get_base_url();

const get_header = () => {
	return {
	'Accept':'application/json',
	'Content-Type': 'application/json',
	'X-CSRFToken': Cookies.get('csrftoken')
    };
}

export const get_users = (user_type =null, debug=false) => {
    var headers = get_header();
    var body = {
    };

    if(user_type != null){
	body['user_type']=user_type
    }

    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'get',
	    url: base_url + 'get-users/', 
	    params: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}

export const send_request = (sponsor_username, view_as = "", debug=false) => {
    var headers = get_header();
    var body = {
	sponsor_username: sponsor_username,
	"view_as" : view_as
    };


    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url: base_url+'sponsor-request/', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }
}

export const respond_request = (driver_username, new_status, debug=false) => {
    var headers = get_header();
    var body = {
	driver_username: driver_username,
	new_status : new_status,
    };


    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url: base_url+'sponsor-request/', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }
}

export const get_requests = (view_as= "") => {
    var headers = get_header();
    console.log("hello");
	var body = {
		"view_as": view_as
	}

    try{
	const res = axios({
	    method: 'get',
	
	    url: base_url+'sponsor-request/', 
		data:body,
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }
    
}
export const get_drivers = (view_as= "") => {
	var headers= get_header();
	console.log("hello");
	var body = {
		"view_as": view_as
	}

	try{
		const res = axios({
			method: 'get',
			url:base_url+'driver-info/',
			data:body,
			headers: headers});
		return res;
	}catch{
		return {'error':'request failed to send'};

	}
}
export const change_points = (username, points, reason, view_as= "") => {
	var headers = get_header();
	console.log("pointy points");
	console.log(username);
	console.log(points);
	console.log(reason);
	var body ={
		'driver_username':username,
		'point_change':points,
		'reason':reason,
		"view_as": view_as
	};
	try{
		const res= axios({
			method:'post',
			url: base_url + 'driver-info/',
			data: body,
			headers:headers});
		console.log(res);
		return res;
	}catch{
		return{'error':'request failed to send'};
	}
}
	
export const sponsor_info = (view_as = "") => {
	var headers= get_header();
	console.log("hello");
	var body = {
		"view_as" : view_as
	}

	try{
		const res = axios({
			method: 'get',
			url:base_url+'sponsor-info/',
			headers: headers});
		return res;
	}catch{
		return {'error':'request failed to send'};

	}
}

export const change_rate = (rate,  view_as = "") => {
	var headers = get_header();
	
	
	var body ={
		'points_to_cents':rate,
		"view_as" : view_as
	};
	try{
		const res= axios({
			method:'post',
			url: base_url + 'sponsor-info/',
			data: body,
			headers:headers});
		console.log(res);
		return res;
	}catch{
		return{'error':'request failed to send'};
	}
}

export const sponsor_all_reports = (name = "", start = "", end = "") => {
	var headers= get_header();
	console.log("hello");
	console.log(start);
	console.log(end);

	var body = {
    };

	if(name != ""){
		body['driver_username']=name
		}
	if(start != ""){
		body['date_start']=start
	}
	if(end != ""){
		body['date_end']=end
	}

	
	try{
		const res = axios({
			method: 'get',
			url:base_url+'sponsor-report/',
			params:body,
			headers: headers});
		return res;
	}catch{
		return {'error':'request failed to send'};

	}
	


}

export const admin_reports = (name = "",start= "",end= "") => {
    var headers= get_header();
    console.log("admin report gathering");
    var body = {
    };

    if(name != ""){
        body['driver_username']=name
    }
	if(start != ""){
		body['date_start']=start
	}
	if(start != ""){
		body['date_end']=end
	}
    try{
        const res = axios({
            method: 'get',
            url:base_url+'purchase-report/',
            params:body,
            headers: headers});
        return res;
    }catch{
        return {'error':'request failed to send'};
	}
}

export const admin_get_sponsor_info = (username) => {
	var headers = get_header();
	var body ={
		'sponsor_username':username,
	}
	try{
		const res= axios({
			method:'get',
			url: base_url + 'driver-info/',
			params: body,
			headers:headers});
		return res;
	}catch{
		return{'error':'request failed to send'};
	}
}

export const admin_get_driver_info = (username) => {
	var headers = get_header();
	var body ={
		'driver_username':username,
	}
	try{
		const res= axios({
			method:'get',
			url: base_url + 'sponsor-info/',
			params: body,
			headers:headers});
		return res;
	}catch{
		return{'error':'request failed to send'};
	}
}

