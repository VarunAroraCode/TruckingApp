import React, { Component } from 'react';
import axios from 'axios';

class CSRFToken extends Component{
	getCookie(name){
		let cookieValue = null;
		if (document.cookie && document.cookie !== '') {
			let cookies = document.cookie.split(';');
			for (let i = 0; i < cookies.length; i++) {
				let cookie = cookies[i].trim();
				if (cookie.substring(0, name.length + 1) === (name + '=')) {
					cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
					break;
				}
			}
		}
		return cookieValue;
	}

	constructor(props){
		super(props);
		this.state = {
			csrf : this.getCookie('csrftoken')
		};
	}

	render(){
		return (
			<input type='hidden' name='csrfmiddlewaretoken' value={this.state.csrf} />
		);
	}
}
export default CSRFToken 
