import Cookies from 'js-cookie';
import axios from 'axios';
import { get_base_url } from './util.jsx';


var base_url = get_base_url();

const get_header = () => {
	return {
	'Accept':'application/json',
	'Content-Type': 'application/json',
	'X-CSRFToken': Cookies.get('csrftoken')
    };
}

export const set_csrf = () => {

    try{
	const res = axios({
	    method: 'get',
	    url:base_url + 'set-csrf/', 
	    withCredentials: true,
	    });
	return res;
    }catch{
	return {'error': 'set csrf failed for unknown reason'};
    }
}

export const register = (username, email, password, re_password, user_type,first_name, last_name, debug=false) => {
    var headers = get_header();
    var body = {
	'first_name' : first_name,
	'last_name' : last_name,
	'username':username,
	'password':password,
	're_password':re_password,
	'user_type':user_type,
	'email':email,
    };
    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url:base_url + 'register/', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'register failed for unknown reason'};
    }

}

export const login = (username, password, debug=false) => {
    var headers = get_header();
    var body = {
	'username': username,
	'password': password
    };

    if(debug == true){
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'post',
	    url: base_url + 'login/', 
	    data: body, 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'login failed for unknown reason'};
    }
}

export const logout = () => {
    var headers = get_header();

    try{
	const res = axios({
	    method: 'post',
	    url: base_url + 'logout/', 
	    headers: headers});
	return res;
    }catch{
	return {'error': 'logout failed for unknown reason'};
    }
}

