import axios from 'axios';
import Cookies from 'js-cookie';
import { get_base_url } from './util.jsx';


var base_url = get_base_url();

const get_header = () => {
	return {
	'Accept':'application/json',
	'Content-Type': 'application/json',
	'X-CSRFToken': Cookies.get('csrftoken')
    };
}

export const get_cart = (debug=false) => {
    var headers = get_header();

    try{
	const res = axios({
	    method: 'get',
	    url: base_url + 'ebay/cart',
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}


export const ebay_search = (search, debug=false) => {
    var headers = get_header();
    var body = {
	'search': search,
    };

    if(debug == true){
	console.log(search);
	console.log(body);
    }

    try{
	console.log(search);
	console.log(body);
	const res = axios({
	    method: 'get',
	    url: base_url + 'ebay/search',
	    params: body,
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}

export const add_to_shop = (productName, productCost, productReviews, image, view_as = "", debug=false) => {
    var headers = get_header();

	console.log(productName);
	console.log(productCost);
	console.log(productReviews);
	console.log(image);
    var body = {
	'add' : [
		{

	'productName': productName,
	'productCost': productCost,
	'productReviews': productReviews,
	'image' : image,
	 'view_as': view_as
		}
	]

    };

    if(debug == true){
    }

    try{
	const res = axios({
	    method: 'post',
	    url: base_url + 'ebay/sponsor-shop',
	    data: body,
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}

export const get_catalog = (view_as = "",debug=false) => {
    var headers = get_header();
	var body ={
		"view_as": view_as
	}

    try{
	const res = axios({
	    method: 'get',
	    url: base_url + 'ebay/sponsor-shop',
		params: body,
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}

export const remove_from_shop = (productName, productCost, productReviews, image, view_as = "", debug=false) => {
    var headers = get_header();

	console.log(productName);
	console.log(productCost);
	console.log(productReviews);
	console.log(image);
    var body = {
	'remove' : [
		{

	'productName': productName,
	'productCost': productCost,
	'productReviews': productReviews,
	'image' : image,
	'view_as': view_as
		}
	]

    };

    if(debug == true){
    }

    try{
	const res = axios({
	    method: 'post',
	    url: base_url + 'ebay/sponsor-shop',
	    data: body,
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}

export const related_shop = (view_as = "", debug=false) => {
    var headers = get_header();
	var body = {
		"view_as": view_as
	}

    if(debug == true){
	console.log(username);
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'get',
	    url: base_url + 'ebay/related-shop',
		params: body,
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}
export const driver_shop = (view_as = "",debug=false) => {
    var headers = get_header();
	var body = {
		"view_as": view_as
	}

    if(debug == true){
	console.log(username);
	console.log(body);
    }

    try{
	const res = axios({
	    method: 'get',
	    url: base_url + 'ebay/driver-shop',
		params: body,
	    headers: headers});
	return res;
    }catch{
	return {'error': 'request failed to send'};
    }

}
