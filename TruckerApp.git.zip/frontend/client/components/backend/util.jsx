
export const get_base_url = () => {
	const dev_url = 'http://127.0.0.1/';
	const prod_url = 'http://ec2-52-205-135-163.compute-1.amazonaws.com/';
	return dev_url;
}
