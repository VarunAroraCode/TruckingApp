const express = require('express');
const app = express();
const axios = require('axios');
const { ModalBody } = require('react-bootstrap');
const port = 3000;

app.use(express.static('public'));

app.get('/LoginInfo', (req, res) => {
  const property = 'driver'
  res.send(property)
})
app.listen(port, () => console.log("listening on port 3000!"));