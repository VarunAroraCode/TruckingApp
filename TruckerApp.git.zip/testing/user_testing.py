from django.contrib.auth import get_user_model
from django.apps import apps
from rest_framework.test import RequestsClient
from web.trucker_api.serializers import UserSerializer, RequestSerializer, SponsorSerializer, DriverSerializer
import json


User = get_user_model()
# ----- Test Functions ----

def print_all_users():
    users = User.objects.all()
    for user in users:
        print(UserSerializer(user).data)

def remove_all_users():
    users = User.objects.all()
    for user in users:
        user.delete()

