import testing.user_testing as testing

#testing.remove_all_users()
testing.print_all_users()
