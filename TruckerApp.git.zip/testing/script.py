import requests
from bs4 import BeautifulSoup

base_url = 'http://ec2-52-205-135-163.compute-1.amazonaws.com/'

def register_test():
    client = requests.session()
    client.get(base_url+'set-csrf')
    csrftoken = client.cookies['csrftoken']

    data = {
        'username':'t',
        'password':'t',
        're_password':'t',
        'user_type':'D',
        'first_name':'f',
        'last_name':'l',
        'email': 'abc@example.com',
        'csrfmiddlewaretoken':csrftoken,
    }
    r = client.post(base_url+'register/', data=data, headers=dict(Referer=base_url))
    print(r.json())
    
def register_walmart():
    client = requests.session()
    client.get(base_url+'set-csrf')
    csrftoken = client.cookies['csrftoken']

    data = {
        'username':'walmart',
        'password':'walmart',
        're_password':'walmart',
        'user_type':'S',
        'first_name':'walmart',
        'last_name':'walmart',
        'email': 'walmart@example.com',
        'csrfmiddlewaretoken':csrftoken,
    }
    r = client.post(base_url+'register/', data=data, headers=dict(Referer=base_url))
    print(r.json())

def login(username, password):
    client = requests.session()
    r = client.get(base_url+'set-csrf')
    print(r.json())
    csrftoken = client.cookies['csrftoken']

    data = {
        'username': username,
        'password': password,
        'csrfmiddlewaretoken':csrftoken,
    }
    r = client.post(base_url+'login/', data=data, headers=dict(Referer=base_url))
    assert('success' in r.json())
    return csrftoken

def my_info(csrftoken):
    client = requests.session()

    data = {
        'csrfmiddlewaretoken':csrftoken,
    }

    r = client.get(base_url+'my-info', params=data, headers=dict(referer=base_url))
    print(r.json())

def get_requests(csrftoken):
    client = requests.session()
    data = {
        'csrfmiddlewaretoken':csrftoken,
    }

    r = client.get(base_url+'sponsor-request', params=data, headers=dict(referer=base_url))
    print(r.json())


def send_request(csrftoken):
    client = requests.session()

    data = {
        'sponsor_username':'walmart',
        'csrfmiddlewaretoken':csrftoken,
    }

    r = client.post(base_url+'sponsor-request/', data=data, headers=dict(Referer=base_url))
    print(r.json())
    assert('success' in r.json())

csrftoken = login('t','t')
#my_info(csrftoken)
#get_requests(csrftoken)
#send_request(csrftoken)
