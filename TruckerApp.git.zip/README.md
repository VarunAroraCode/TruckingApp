# TruckerApp

This repository serves as a collaborative space for our Good Driver Program application. Our software stack is as follows:

Front-End: 
React

Framework:
djengo

API Format:
Rest API

Back-End:
Python

DB:
SQL-Lite

Compute:
EC2

Storage:
EBS
